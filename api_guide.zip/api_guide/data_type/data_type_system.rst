.. _ispOpTypeE:

enum ispOpTypeE
----------------

**typedef enum cnispOpTypeE**

**{**
  
  **E_OP_TYPE_AUTO = 0,**

  **E_OP_TYPE_MANUAL = 1,**

  **E_OP_TYPE_BUTT = 2,**

**} ispOpTypeE;**

模块运行模式。

**成员说明**

* E_OP_TYPE_AUTO

  运行在自动模式下。

* E_OP_TYPE_MANUAL

  运行在手动模式下。

* E_OP_TYPE_BUTT

  无效值。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispDemosaicConfigE:

enum ispDemosaicConfigE
------------------------

**typedef enum cnispDemosaicConfigE**

**{**
  
  **E_DEMOSAIC_CFG_CLOSE = 0,**

  **E_DEMOSAIC_CFG_UU = 4,**

  **E_DEMOSAIC_CFG_AA = 17,**

  **E_DEMOSAIC_CFG_VA = 18,**

  **E_DEMOSAIC_CFG_VH = 19,**

  **E_DEMOSAIC_CFG_HF = 27,**

  **E_DEMOSAIC_CFG_GRAY = 31,**

  **E_DEMOSAIC_CFG_LG = 32,**

  **E_DEMOSAIC_CFG_BUTT = 33,**

**} ispDemosaicConfigE;**

去马赛克调试模式。

**成员说明**

* E_DEMOSAIC_CFG_CLOSE

  关闭去马赛克调试。

* E_DEMOSAIC_CFG_UU

  UU 无方向性调试模式。

* E_DEMOSAIC_CFG_AA

  AA 45度/135度调试模式。

* E_DEMOSAIC_CFG_VA

  VA 水平/垂直/45度/135度调试模式。

* E_DEMOSAIC_CFG_VH

  VH 水平/垂直调试模式。

* E_DEMOSAIC_CFG_HF

  高频调试模式。

* E_DEMOSAIC_CFG_GRAY

  灰度调试模式。

* E_DEMOSAIC_CFG_LG

  低绿调试模式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispWdrMode:

enum ispWdrMode
----------------

**typedef enum cnispWdrModeE**

**{**

  **E_MODE_LINE = 0,**
  
  **E_MODE_MUX2TO3 = 1,**
  
  **E_MODE_LOGARITHMIC_ENCODING = 2,**
  
  **E_MODE_COMPANDING_CURVE_KNEE = 3,**
  
  **E_MODE_LINEAR16_AND_VS12 = 4,**
  
  **E_MODE_COMPANDED12_AND_VS12 = 5,**
  
  **E_MODE_DOL = 7,**

**} ispWdrMode;**

宽动态范围模式。

**成员说明**

* E_MODE_LINE

  线性模式。

* E_MODE_MUX2TO3

  2帧转3帧模式。

* E_MODE_LOGARITHMIC_ENCODING

  Log 对数算法模式。

* E_MODE_COMPANDING_CURVE_KNEE

  Curve-knee 自定义曲线拐点算法模式。

* E_MODE_LINEAR16_AND_VS12

  LINEAR16_AND_VS12 模式，该模式将2帧16比特线性数据和极短帧12比特压缩数据转换成换成3帧数据。

* E_MODE_COMPANDED12_AND_VS12

  COMPANDED12_AND_VS12 模式，该模式将2帧12比特压缩数据和极短帧12比特压缩数据转换成换成3帧数据。

* E_MODE_DOL

  多帧模式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispDataSrc:

enum ispDataSrc
----------------

**typedef enum cnispDataSrcE**

**{**
  
  **E_SRC_SENSOR_LINE_SITCHED_BY_SENSOR = 0,**

  **E_SRC_STICHED_BY_ISP = 1,**

  **E_SRC_DECOMANDED = 2,**

**} ispDataSrc;**

帧数据来源。

**成员说明**

* E_SRC_SENSOR_LINE_SITCHED_BY_SENSOR

  直接从 sensor 获取帧数据。

* E_SRC_STICHED_BY_ISP

  在 sensor 数据经过 ISP 帧融合后再获取帧数据。

* E_SRC_DECOMANDED

  在 sensor 数据经过解压缩后再获取帧数据。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispBayerBitsWidth:

enum ispBayerBitsWidth
-----------------------

**typedef enum cnispBayerBitsWidthE**

**{**
  
  **E_BIT_WIDTH_8 = 0,**

  **E_BIT_WIDTH_10 = 1,**

  **E_BIT_WIDTH_12 = 2,**

  **E_BIT_WIDTH_14 = 3,**

  **E_BIT_WIDTH_16 = 4,**

  **E_BIT_WIDTH_20 = 5,**

**} ispBayerBitsWidth;**

Bayer帧位宽。

**成员说明**

* E_BIT_WIDTH_8

  8 比特 位宽。

* E_BIT_WIDTH_10

  10 比特 位宽。

* E_BIT_WIDTH_12

  12 比特 位宽。

* E_BIT_WIDTH_14

  14 比特 位宽。

* E_BIT_WIDTH_16

  16 比特 位宽。

* E_BIT_WIDTH_20

  20 比特 位宽。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispBayerPatternE:

enum ispBayerPatternE
----------------------

**typedef enum cnispBayerPatternE**

**{**
  
  **E_BAYER_RGGB = 0,**

  **E_BAYER_GRBG = 1,**

  **E_BAYER_GBRG = 2,**

  **E_BAYER_BGGR = 3,**

  **E_BAYER_RIrGB = 6,**

  **E_BAYER_RGIrB = 7,**

**} ispBayerPatternE;**

Bayer CFA（Color Filter Array，色彩滤波阵列）格式。

**成员说明**

* E_BAYER_RGGB

  RGGB格式。

* E_BAYER_GRBG

  GRBG格式。

* E_BAYER_GBRG

  GBRG格式。

* E_BAYER_BGGR

  BGGR格式。

* E_BAYER_RIrGB

  RIrGB格式。

* E_BAYER_RGIrB

  RGIrB格式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispExposureMode:

enum cnispExposureMode
-----------------------

**typedef enum cnispExposureModeE**

**{**
  
  **E_EX_MODE_FOUR = 0,**

  **E_EX_MODE_TWO = 1,**

  **E_EX_MODE_THREE = 2,**

  **E_EX_MODE_ONE = 3,**

**} cnispExposureMode;**

曝光模式。

**成员说明**

* E_EX_MODE_FOUR

  四曝光模式。

* E_EX_MODE_TWO

  两曝光模式。

* E_EX_MODE_THREE

  三曝光模式。

* E_EX_MODE_ONE

  一曝光模式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispOutPutSelectE:

enum ispOutPutSelectE
----------------------

**typedef enum cnispOutPutSelectE**

**{**
  
  **E_NORMAL_STITCHED_OUTPUT = 0,**

  **E_LONG_DATA_ROUTED_OUT = 1,**

  **E_MEDIUM_DATA_ROUTED_OUT = 2,**

  **E_SHORT_DATA_ROUTED_OUT = 4,**

  **E_VERY_SHORT_DATA_ROUTED_OUT = 8,**

  **E_LM_STITCHED_OUTPUT_TAKEN_OUT = 16,**

  **E_MS_STITCHED_OUTPUT_TAKEN_OUT = 32,**

  **E_SVS_STITCHED_OUTPUT_TAKEN_OUT = 64,**

**} ispOutPutSelectE;**

输出模式属性。

**成员说明**

* E_NORMAL_STITCHED_OUTPUT

  正常融合模式。

* E_LONG_DATA_ROUTED_OUT

  长帧输出模式。

* E_MEDIUM_DATA_ROUTED_OUT

  中帧输出模式。

* E_SHORT_DATA_ROUTED_OUT

  短帧输出模式。

* E_VERY_SHORT_DATA_ROUTED_OUT

  极短帧输出模式。

* E_LM_STITCHED_OUTPUT_TAKEN_OUT

  中-长帧融合输出模式。

* E_MS_STITCHED_OUTPUT_TAKEN_OUT

  中-短帧融合输出模式。

* E_SVS_STITCHED_OUTPUT_TAKEN_OUT

  短-极短帧融合输出模式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispRegTypeE:

enum ispRegTypeE
-----------------

**typedef enum cnispRegTypeE**

**{**
  
  **E_REG_TYPE_ISP = 1,**

  **E_REG_TYPE_SENSOR = 2,**

  **E_REG_TYPE_LENS = 3,**

  **E_REG_TYPE_BUTT = 4,**

**} ispRegTypeE;**

寄存器类型属性。

**成员说明**

* E_REG_TYPE_ISP

  ISP内部寄存器。

* E_REG_TYPE_SENSOR

  Sensor寄存器。

* E_REG_TYPE_LENS

  Lens寄存器。

* E_REG_TYPE_BUTT

  无效值。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispFogMeterModeE:

enum ispFogMeterModeE
----------------------

**typedef enum cnispFogMeterModeE**

**{**
  
  **E_FOG_METER_PTILE = 0,**

  **E_FOG_METER_HISTEXP = 1,**

  **E_FOG_METER_WEIAVG = 2,**

  **E_FOG_METER_BUTT = 3,**

**} ispFogMeterModeE;**

去雾统计信息模式。

**成员说明**

* E_FOG_METER_PTILE

  使用直方图75位置作为测量值。

* E_FOG_METER_HISTEXP

  使用直方图均值作为测量值。

* E_FOG_METER_WEIAVG

  使用平均权重作为测量值。

* E_FOG_METER_BUTT

  无效值。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDitherMode_e:

enum cnispDitherMode_e
-----------------------

**typedef enum**

**{**
  
  **E_ISP_DITHER_LSFR = 0,**

  **E_ISP_DITHER_BAYER = 1,**

  **E_ISP_DITHER_ERR_DIFFUSION = 2,**

**} cnispDitherMode_e;**

抖动模式。

**成员说明**

* E_ISP_DITHER_LSFR

  随机抖动抖动模式。

* E_ISP_DITHER_BAYER

  Bayer有序抖动抖动模式。

* E_ISP_DITHER_ERR_DIFFUSION

  误差扩散抖动模式。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispControl_t:

struct cnispControl_t
----------------------

**typedef struct cnispControl**

**{**
  
  **cnU32_t u32ActiveHeight;**

  **cnU32_t u32ActiveWidth;**

  **cnU32_t u32RGGBStartPreMirror;**

  **cnU32_t u32RGGBStartPostMirror;**

  **cnU32_t u32CfaPattern;**

  **cnU32_t u32LinearDataSrc;**

  **cnU32_t u32AE5binHistDisable;**

  **cnU32_t u32AESwitch;**

  **cnU32_t u32AFDisable;**

  **cnU32_t u32AWBDisable;**

  **cnU32_t u32AWBSwitch;**

  **cnU32_t u32AEXPHistDisable;**

  **cnU32_t u32AEXPHistogramSwitch;**

  **cnU32_t u32IHistDisable;**

  **cnU32_t u32LumavarDisable;**

  **cnU32_t u32LumavarSwitch;**

  **cnU32_t u32AexpSrc;**

**} cnispControl_t;**

控制信息属性。

**成员说明**

* u32ActiveHeight

  视频高度。取值范围为[0x80,0xD80]，只读属性。

* u32ActiveWidth

  视频宽度。取值范围为[0x80,0x1200]，只读属性。

* u32RGGBStartPreMirror

  镜像前的RGGB格式。取值范围为[0x0,0x3]，只读属性。

* u32RGGBStartPostMirror

  镜像后的RGGB格式。取值范围为[0x0,0x3]，只读属性。

* u32CfaPattern

  颜色滤波矩阵格式。取值范围为[0x0,0x3]，只读属性。

* u32LinearDataSrc

  线性数据源。取值范围为[0x0,0x2]，只读属性。

* u32AE5binHistDisable

  去使能自动曝光的5bin直方图。取值范围为[0x0,0x1]。

* u32AESwitch

  自动曝光的5bin直方图统计选择。取值范围为[0x0,0x2]。

* u32AFDisable

  去使能自动对焦。取值范围为[0x0,0x1]，只读属性。

* u32AWBDisable

  去使能自动白平衡。取值范围为[0x0,0x1]。

* u32AWBSwitch

  白平衡插入点切换。取值范围为[0x0,0x1]。

* u32AEXPHistDisable

  去使能全局直方图。取值范围为[0x0,0x1]。

* u32AEXPHistogramSwitch

  1024全局直方图统计位置选择。取值范围为[0x0,0x2]。

* u32IHistDisable

  在动态范围压缩后去使能直方图。取值范围为[0x0,0x1]。

* u32LumavarDisable

  亮度方差统计使能。取值范围为[0x0,0x1]。

* u32LumavarSwitch

  亮度方差，用于编码。取值范围为[0x0,0x1]。

* u32AexpSrc

  应用白色平衡的节点。取值范围为[0x0,0x1]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispPub_t:

struct cnispPub_t
------------------

**typedef struct cnispPub**

**{**
  
  **cnU32_t u32ActiveHeight;**

  **cnU32_t u32ActiveWidth;**

  **cnU32_t u32InputMode;**

  **cnU32_t u32InputBitsWidth;**

  **cnU32_t u32LineDataSrc;**

  **cnU32_t u32BayerPattern;**

  **cnU32_t u32FrameRate;**

  **cnU32_t u32WdrMode;**

**} cnispPub_t;**

公共属性。

**成员说明**

* u32ActiveHeight

  视频高度。取值范围为[0x0,0xffff]，只读属性。

* u32ActiveWidth

  视频宽度。取值范围为[0x0,0xffff]，只读属性。

* u32InputMode

  输入模式。取值范围为[0x0,0x6)(0x6,0x7]，只读属性。

* u32InputBitsWidth

  输入的比特位宽。取值范围为[0x0,0x5]，只读属性。

* u32LineDataSrc

  线性数据源。取值范围为[0x0,0x2]，只读属性。

* u32BayerPattern

  拜耳格式。取值范围为[0x0,0x3][0x6,0x7]。

* u32FrameRate

  帧率。取值范围为[0x0,0xffff]，只读属性。

* u32WdrMode

  宽动态模式。取值范围为[0x0,0x3]，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispByPass_t:

struct cnispByPass_t
---------------------

**typedef struct cnispByPass**

**{**
  
  **cnU8_t u8BypassVideoTestGen;**

  **cnU8_t u8BypassInputFormatter;**

  **cnU8_t u8BypassDecompander;**

  **cnU8_t u8BypassSensorOffsetWdr;**

  **cnU8_t u8BypassGainWdr;**

  **cnU8_t u8BypassFrameStitch;**

  **cnU8_t u8BypassDigitalGain;**

  **cnU8_t u8BypassFrontendSensorOffset;**

  **cnU8_t u8BypassFeSqrt;**

  **cnU8_t u8BypassRAWFrontend;**

  **cnU8_t u8BypassDefectPixel;**

  **cnU8_t u8BypassSinter;**

  **cnU8_t u8BypassTemper;**

  **cnU8_t u8BypassCaCorrection;**

  **cnU8_t u8BypassSquareBe;**

  **cnU8_t u8BypassSensorOffsetPreShading;**

  **cnU8_t u8BypassRadialShading;**

  **cnU8_t u8BypassMeshShading;**

  **cnU8_t u8BypassWhiteBalance;**

  **cnU8_t u8BypassIridixGain;**

  **cnU8_t u8BypassIridix;**

  **cnU8_t u8BypassDemosaicRgb;**

  **cnU8_t u8BypassDemosaicRgbir;**

  **cnU8_t u8BypassPfCorrection;**

  **cnU8_t u8BypassCCM;**

  **cnU8_t u8BypassCNR;**

  **cnU8_t u8Bypass3DLut;**

  **cnU8_t u8BypassNonequGamma;**

  **cnU8_t u8BypassFrCrop;**

  **cnU8_t u8BypassFrGammaRgb;**

  **cnU8_t u8BypassDefog;**

  **cnU8_t u8BypassCSC;**

  **cnU8_t u8BypassCDS;**

  **cnU8_t u8BypassDither;**

  **cnU8_t u8BypassSharpen;**

  **cnU8_t u8BypassTDNR;**

  **cnU8_t u8BypassRAWBypass;**

  **cnU8_t u8ISPDownscalePipeDisable;**

  **cnU8_t u8ISPProcessginFrBypassMode;**

**} cnispByPass_t;**

旁路属性。

**成员说明**

* u8BypassVideoTestGen

  旁路测试功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassInputFormatter

  旁路输入格式功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDecompander

  旁路数据解压缩功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassSensorOffsetWdr

  旁路传感器偏移宽动态功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassGainWdr

  旁路宽动态增益功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassFrameStitch

  旁路帧融合功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDigitalGain

  旁路数字增益功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassFrontendSensorOffset

  旁路前端传感器偏移功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassFeSqrt

  旁路前端平方根功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassRAWFrontend

  旁路绿平衡和动态坏点校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDefectPixel

  旁路静态坏点校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassSinter

  旁路空域噪声消除功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassCaCorrection

  旁路色差校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassSquareBe

  旁路开平方功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassSensorOffsetPreShading

  旁路阴影偏移，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassRadialShading

  旁路同轴圆阴影校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassMeshShading

  旁路网格阴影校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassWhiteBalance

  旁路白平衡功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassIridixGain

  旁路动态范围压缩增益，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassIridix

  旁路动态范围压缩功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDemosaicRgb

  旁路RGB去马赛克功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDemosaicRgbir

  旁路Rgbir去马赛克功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassPfCorrection

  旁路去紫边校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassCCM

  旁路颜色校正矩阵功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassCNR

  旁路色度降噪功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8Bypass3DLut

  旁路3D查找表功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassNonequGamma

  旁路gamma校正功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassFrCrop

  旁路裁剪功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassFrGammaRgb

  旁路RGB gamma功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDefog

  旁路去雾功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassCSC

  旁路颜色空间转换功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。
  
* u8BypassCDS

  旁路色度降采样功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassDither

  旁路抖动功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassSharpen

  旁路锐化功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassTDNR

  旁路三维降噪功能，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8BypassRAWBypass

  旁路RAWBypass，取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8ISPDownscalePipeDisable

  去使能降采样功能。取值范围：[0x0,0x1]，0x0为非旁路，0x1为旁路，即去使能该功能。

* u8ISPProcessginFrBypassMode

  旁路ISP。取值范围：[0x0,0x2]，0x0为非旁路，0x1为旁路ISP并在TPG之后输出RAW数据中的[19:4]bit，0x2为旁路整个ISP并在TPG之后输出RAW数据中的低10bit。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCrossBar_t:

struct cnispCrossBar_t
-----------------------

**typedef struct cnispCrossBar**

**{**
  
  **cnU8_t u8Channel1;**

  **cnU8_t u8Channel2;**

  **cnU8_t u8Channel3;**

  **cnU8_t u8Channel4;**

**} cnispCrossBar_t;**

Crossbar（图像输入到输出的任意4到4路由）属性。

**成员说明**

* u8Channel1

  通道1选择项。取值范围为[0x0,0x3]。

* u8Channel2

  通道2选择项。取值范围为[0x0,0x3]。

* u8Channel3

  通道3选择项。取值范围为[0x0,0x3]。

* u8Channel4

  通道4选择项。取值范围为[0x0,0x3]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispTpg_t:

struct cnispTpg_t
------------------

**typedef struct cnispTpg**

**{**
  
  **cnU8_t u8TestPatternOffOn;**

  **cnU8_t u8BayerRgbISel;**

  **cnU8_t u8BayerRgbOSel;**

  **cnU8_t u8GenerateMode;**

  **cnU32_t u32VideoSource;**

  **cnU32_t u32PatternType;**

  **cnU32_t u32RBackgnd;**

  **cnU32_t u32GBackgnd;**

  **cnU32_t u32BBackgnd;**

  **cnU32_t u32RForegnd;**

  **cnU32_t u32GForegnd;**

  **cnU32_t u32BForegnd;**

  **cnU32_t u32RgbGradient;**

  **cnU32_t u32RgbGradientStart;**

  **cnU32_t u32RectTop;**

  **cnU32_t u32RectBot;**

  **cnU32_t u32RectLeft;**

  **cnU32_t u32RectRight;**

**} cnispTpg_t;**

测试模式属性。

**成员说明**

* u8TestPatternOffOn

  使能测试模式。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8BayerRgbISel

  输入格式选择项。取值范围为[0x0,0x1]，0x0为Bayer，0x1为RGB。

* u8BayerRgbOSel

  输出格式选择项。取值范围为[0x0,0x1]，0x0为Bayer，0x1为RGB。

* u8GenerateMode

  输出连续性选择项。取值范围为[0x0,0x1]，0x0为一帧脉冲，0x1为连续。

* u32VideoSource

  视频数据选择项。取值范围为[0x0,0x1]，0x0为视频接口，0x1为内部视频生成。

* u32PatternType

  测试图像格式选择项。取值范围为[0x0,0xff]。

* u32RBackgnd

  红色背景。取值范围为[0x0,0xfffff]。

* u32GBackgnd

  绿色背景。取值范围为[0x0,0xfffff]。

* u32BBackgnd

  蓝色背景。取值范围为[0x0,0xfffff]。

* u32RForegnd

  红色前景。取值范围为[0x0,0xfffff]。

* u32GForegnd

  绿色前景。取值范围为[0x0,0xfffff]。

* u32BForegnd

  蓝色前景。取值范围为[0x0,0xfffff]。

* u32RgbGradient

  RGB梯度增量。取值范围为[0x0,0xffff]。

* u32RgbGradientStart

  RGB梯度增量起始值。取值范围为[0x0,0xfffff]。

* u32RectTop

  矩形顶部行数。取值范围为[0x0,0x3fff]。

* u32RectBot

  矩形底部行数。取值范围为[0x0,0x3fff]。

* u32RectLeft

  矩形左侧行数。取值范围为[0x0,0x3fff]。

* u32RectRight

  矩形右侧行数。取值范围为[0x0,0x3fff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispInputFormat_t:

struct cnispInputFormat_t
--------------------------

**typedef struct cnispInputFormat**

**{**
  
  **cnU32_t u32ModeIn;**

  **cnU32_t u32InputBitwidthSelect;**

  **cnU32_t u32FactorML;**

  **cnU32_t u32FactorMS;**

  **cnU32_t u32BlackLevel;**

  **cnU32_t u32KneePoint0;**

  **cnU32_t u32KneePoint1;**

  **cnU32_t u32KneePoint2;**

  **cnU32_t u32Slop0Select;**

  **cnU32_t u32Slop1Select;**

  **cnU32_t u32Slop2Select;**

  **cnU32_t u32Slop3Select;**

**} cnispInputFormat_t;**

输入格式属性。

**成员说明**

* u32ModeIn

  输入模式。取值范围为[0x0,0x6)(0x6,0x7]。

* u32InputBitwidthSelect

  输入位宽模式。取值范围为[0x0,0x5]。

* u32FactorML

  在2:3复用模式下中-长帧曝光比。取值范围为[0x0,0x3ffff]。

* u32FactorMS

  在2:3复用模式下中-短帧曝光比。取值范围为[0x0,0x1fff]。

* u32BlackLevel

  在2:3复用模式下的黑电平值。取值范围为[0x0,0xfff]。

* u32KneePoint0

  曲线拐点0。取值范围为[0x0,0xffff]。

* u32KneePoint1

  曲线拐点1。取值范围为[0x0,0xffff]。

* u32KneePoint2

  曲线拐点2。取值范围为[0x0,0xffff]。

* u32Slop0Select

  第一阶段斜率。取值范围为[0x0,0xf]。

* u32Slop1Select

  第二阶段斜率。取值范围为[0x0,0xf]。

* u32Slop2Select

  第三阶段斜率。取值范围为[0x0,0xf]。

* u32Slop3Select

  第四阶段斜率。取值范围为[0x0,0xf]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDecompander_t:

struct cnispDecompander_t
--------------------------

**typedef struct cnispDecompander**

**{**
  
  **cnU32_t u32De0Enable;**

  **cnU32_t u32De0OffsetMode;**

  **cnU32_t u32De1Enable;**

  **cnU32_t u32De1OffsetMode;**

**} cnispDecompander_t;**

解压缩属性。

**成员说明**

* u32De0Enable

  使能解压缩通道0。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32De0OffsetMode

  解压缩通道0偏移量。取值范围为[0x0,0x1]。

* u32De1Enable

  使能解压缩通道1。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32De1OffsetMode

  解压缩通道1偏移量。取值范围为[0x0,0x1]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispFsWdrManual_t:

struct cnispFsWdrManual_t
--------------------------

**typedef struct cnispFsWdrManual**

**{**
  
  **cnU8_t u8ModeIn;**

  :ref:`ispOutPutSelectE<ispOutPutSelectE>` **eOutputSelect;**

  **cnU16_t u16LmExposureRatio;**

  **cnU16_t u16MsExposureRatio;**

  **cnU16_t u16SvsExposureRatio;**

  **cnU32_t u32LmThreshHigh;**

  **cnU32_t u32LmThreshLow;**

  **cnU32_t u32MsThreshHigh;**

  **cnU32_t u32MsThreshLow;**

  **cnU32_t u32SvsThreshHigh;**

  **cnU32_t u32SvsThreshLow;**

  **cnU32_t u32BlackLevelLong;**

  **cnU32_t u32BlackLevelMedium;**

  **cnU32_t u32BlackLevelShort;**

  **cnU32_t u32BlackLevelVeryShort;**

  **cnU32_t u32BlackLevelOut;**

  **cnU32_t u32LmNpMult;**

  **cnU32_t u32MsNpMult;**

  **cnU32_t u32SvsNpMult;**

  **cnU32_t u32LmAlphaMovSlope;**

  **cnU32_t u32MsAlphaMovSlope;**

  **cnU32_t u32SvsAlphaMovSlope;**

  **cnU32_t u32GainR;**

  **cnU32_t u32GainB;**

  **cnU32_t u32ConsistencyThreshMov;**

  **cnU32_t u32ConsistencyThreshLvl;**

  **cnU32_t u32LmNoiseThresh;**

  **cnU32_t u32LmPosWeight;**

  **cnU32_t u32LmNegWeight;**

  **cnU32_t u32LmMedNoiseAlphaThresh;**

  **cnU32_t u32LmMedNoiseIntensityThresh;**

  **cnU32_t u32LmMcBlendSlope;**

  **cnU32_t u32LmMcBlendThresh;**

  **cnU32_t u32LmMcBlendOffset;**

  **cnU32_t u32LmMcThreshSlope;**

  **cnU32_t u32LmMcThreshThresh;**

  **cnU32_t u32LmMcThreshOffset;**

  **cnU32_t u32LmMcMagThreshSlope;**

  **cnU32_t u32LmMcMagThreshThresh;**

  **cnU32_t u32LmMcMagThreshOffset;**

  **cnU32_t u32LmMcMagLblendThresh;**

  **cnU32_t u32McoffWbOffset;**

  **cnU32_t u32ExposureMaskThresh;**

  **cnU32_t u32BwbSelect;**

  **cnU32_t u32UseMax;**

  **cnU32_t u32McoffNcEnable;**

  **cnU32_t u32McoffModeEnable;**

  **cnU32_t u32LmAlgSelect;**

  **cnU32_t u32McoffLMax;**

  **cnU32_t u32McoffMMax;**

  **cnU32_t u32McoffSMax;**

  **cnU32_t u32McoffVsMax;**

  **cnU32_t u32McoffLScaler;**

  **cnU32_t u32McoffLmScaler;**

  **cnU32_t u32McoffLmsScaler;**

  **cnU32_t u32McoffNcThreshLow;**

  **cnU32_t u32McoffNcThreshHigh;**

  **cnU32_t u32McoffNcScale;**

  **cnU32_t u32GainL;**

  **cnU32_t u32GainM;**

  **cnU32_t u32GainS;**

  **cnU32_t u32GainVs;**

  **cnU32_t u32BlackLevelL;**

  **cnU32_t u32BlackLevelM;**

  **cnU32_t u32BlackLevelS;**

  **cnU32_t u32BlackLevelVs;**

**} cnispFsWdrManual_t;**

帧融合宽动态手动参数属性。

**成员说明**

* u8ModeIn

  曝光模式。取值范围为[0x0,0x3]，只读属性。

* eOutputSelect

  调试选择项。取值范围为[0x0,0x2][0x4][0x8][0x10][0x20][0x40]。

* u16LmExposureRatio

  中-长帧曝光率。取值范围为[0x0,0xfff]。

* u16MsExposureRatio

  中-短帧曝光率。取值范围为[0x0,0xfff]。

* u16SvsExposureRatio

  短-极短帧曝光率。取值范围为[0x0,0xfff]。

* u32LmThreshHigh

  中-长帧高位阈值，高于这个阈值的数据将只从中曝光中获取。取值范围为[0x0,0xfff]。

* u32LmThreshLow

  中-长帧低位阈值，低于这个阈值的数据将只从长曝光中获取。取值范围为[0x0,0xfff]。

* u32MsThreshHigh

  中-短帧高位阈值，高于这个阈值的数据将只从短曝光中获取。取值范围为[0x0,0xfff]。

* u32MsThreshLow

  中-短帧低位阈值，低于这个阈值的数据将只从中曝光中获取。取值范围为[0x0,0xfff]。

* u32SvsThreshHigh

  短-极短帧高位阈值，高于这个阈值的数据将只从极短曝光中获取。取值范围为[0x0,0xfff]。

* u32SvsThreshLow

  短-极短帧低位阈值，低于这个阈值的数据将只从短曝光中获取。取值范围为[0x0,0xfff]。

* u32BlackLevelLong

  长帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelMedium

  中帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelShort

  短帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelVeryShort

  极短帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelOut

  黑电平输出。取值范围为[0x0,0xfffff]。

* u32LmNpMult

  中-长帧噪声权重系数。取值范围为[0x0,0xfff]。

* u32MsNpMult

  中-短帧噪声权重系数。取值范围为[0x0,0xfff]。

* u32SvsNpMult

  短-极短帧噪声权重系数。取值范围为[0x0,0xfff]。

* u32LmAlphaMovSlope

  中-长帧运动 alpha 斜率。取值范围为[0x0,0xfff]。

* u32MsAlphaMovSlope

  中-短帧运动 alpha 斜率。取值范围为[0x0,0xfff]。

* u32SvsAlphaMovSlope

  短-极短帧运动 alpha 斜率。取值范围为[0x0,0xfff]。

* u32GainR

  R分量倍率。取值范围为[0x0,0xfff]。

* u32GainB

  B分量倍率。取值范围为[0x0,0xfff]。

* u32ConsistencyThreshMov

  像素移动阈值。取值范围为[0x0,0xfff]。

* u32ConsistencyThreshLvl

  像素闪烁阈值。取值范围为[0x0,0xfffff]。

* u32LmNoiseThresh

  中-长帧噪声差异阈值。取值范围为[0x0,0x3f]。

* u32LmPosWeight

  中-长帧噪声差异正向权重。取值范围为[0x0,0x3f]。

* u32LmNegWeight

  中-长帧噪声差异反向权重。取值范围为[0x0,0x3f]。

* u32LmMedNoiseAlphaThresh

  判断短帧的alpha阈值，运动检测超过此Alpha阈值时，像素选用短帧。取值范围为[0x0,0xfff]。

* u32LmMedNoiseIntensityThresh

  噪声强度阀值，短帧最小像素值，如果短帧的像素值小于此值，则将该值设置为生效像素值。取值范围为[0x0,0xfff]。

* u32LmMcBlendSlope

  预留。取值范围为[0x0,0x3fffff]。

* u32LmMcBlendThresh

  预留。取值范围为[0x0,0xff]。

* u32LmMcBlendOffset

  预留。取值范围为[0x0,0xfff]。

* u32LmMcThreshSlope

  预留。取值范围为[0x0,0x3fffff]。

* u32LmMcThreshThresh

  预留。取值范围为[0x0,0xfffff]。

* u32LmMcThreshOffset

  预留。取值范围为[0x0,0xfff]。

* u32LmMcMagThreshSlope

  预留。取值范围为[0x0,0x3fffff]。

* u32LmMcMagThreshThresh

  预留。取值范围为[0x0,0xfffff]。

* u32LmMcMagThreshOffset

  预留。取值范围为[0x0,0xfff]。

* u32LmMcMagLblendThresh

  预留。取值范围为[0x0,0xfff]。

* u32McoffWbOffset

  MCOFF（运动补偿）的 WB 偏移值，当BWB SELECT为1时使能。取值范围为[0x0,0xfff]。

* u32ExposureMaskThresh

  曝光掩码阈值，当 alpha 值高于这个值时,表明是短曝光。取值范围为[0x0,0xff]。

* u32BwbSelect

  选择是否在MCOFF模式拼接前应用白平衡。取值范围为[0x0,0x1]，0x0表示不使用白平衡， 0x1表示使用白平衡。

* u32UseMax

  在计算alpha掩码之前，使用最大33个过滤器放大像素数据。取值范围为[0x0,0x1]，0x0表示不使用最大过滤器。0x1表示使用最大过滤器。

* u32McoffNcEnable

  使能 MCOFF NC（Nosie Core）功能。取值范围为[0x0,0x1]，0x0表示关闭 noise core。0x1表示开启 noise core。（通过在最短帧中丢弃一定范围的像素来提高信噪比）。

* u32McoffModeEnable

  使能 MCOFF 模式。取值范围为[0x0,0x1]，0x0表示不使用 MCOFF 模式。0x1表示使用 MCOFF 模式。

* u32LmAlgSelect

  选择使用哪种 L/M 拼接算法。取值范围为[0x0,0x1]，0x0为通用配置(带LM参数)，0x1为备选配置(带LM_MC参数)。

* u32McoffLMax

  长帧MCOFF最大值。取值范围为[0x0,0xfff]。

* u32McoffMMax

  中帧MCOFF最大值。取值范围为[0x0,0xfff]。

* u32McoffSMax

  短帧MCOFF最大值。取值范围为[0x0,0xfff]。

* u32McoffVsMax

  极短帧MCOFF最大值。取值范围为[0x0,0xfff]。

* u32McoffLScaler

  长帧线性化比例因子。取值范围为[0x0,0xfff]。

* u32McoffLmScaler

  中-长帧线性化比例因子。取值范围为[0x0,0xfff]。

* u32McoffLmsScaler

  长中-短帧线性化比例因子。取值范围为[0x0,0xfff]。

* u32McoffNcThreshLow

  Noise core 的最小阈值，当像素值小于该值时，Noise core 生效。取值范围为[0x0,0xfff]。

* u32McoffNcThreshHigh

  Noise core 的最大阈值，当像素值大于该值时，Noise core 生效。取值范围为[0x0,0xfff]。

* u32McoffNcScale

  在 Noise core 的过度区域，该值越小，变化越平滑。取值范围为[0x0,0xfff]。

* u32GainL

  长帧增益。取值范围为[0x0,0x1fff]。

* u32GainM

  中帧增益。取值范围为[0x0,0x1fff]。

* u32GainS

  短帧增益。取值范围为[0x0,0x1fff]。

* u32GainVs

  极短帧增益。取值范围为[0x0,0x1fff]。

* u32BlackLevelL

  长帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelM

  中帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelS

  短帧黑电平。取值范围为[0x0,0xfff]。

* u32BlackLevelVs

  极短帧黑电平。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispFsWdrAuto_t:

struct cnispFsWdrAuto_t
------------------------

**typedef struct cnispFsWdrAuto**

**{**
  
  **cnU16_t u16StitchingLmNp[16][2];**

  **cnU16_t u16StitchingMsNp[16][2];**

  **cnU16_t u16StitchingLmMedNoiseIntensity[16][2];**

  **cnU16_t u16StitchingLmMovMult[16][2];**

  **cnU16_t u16StitchingMsMovMult[16][2];**

  **cnU16_t u16FsMcOffGainThreshold;**

**} cnispFsWdrAuto_t;**

帧融合宽动态自动参数属性。

**成员说明**

* u16StitchingLmNp[16][2]

  增益-噪声等级系数表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为噪声等级系数，可取值为[0x0,0xfffff]。

* u16StitchingMsNp[16][2]

  增益-动态检测控制斜率起点表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为动态检测控制斜率起始点，可取值为[0x0,0xfffff]。

* u16StitchingLmMedNoiseIntensity[16][2]

  增益-暗曝光像素判断阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为暗曝光像素判断阈值，可取值为[0x0,0xfffff]。

* u16StitchingLmMovMult[16][2]

  增益-中-长帧动态检测坡度值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为中-长帧动态检测坡度值，可取值为[0x0,0xfffff]。

* u16StitchingMsMovMult[16][2]

  增益-中-短帧动态检测坡度值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为中-短帧动态检测坡度值，可取值为[0x0,0xfffff]。

* u16FsMcOffGainThreshold

  帧融合MCOFF阈值，当增益值高于这个阈值时，MCOFF 将被使能。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispFsWdr_t:

struct cnispFsWdr_t
--------------------

**typedef struct cnispFsWdr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispFsWdrManual_t<cnispFsWdrManual_t>` **stFsWdrManual;**

  :ref:`cnispFsWdrAuto_t<cnispFsWdrAuto_t>` **stFsWdrAuto;**

  **cnU8_t u8WdrNpLut[128];**

**} cnispFsWdr_t;**

帧融合宽动态范围属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stFsWdrManual

  帧融合宽动态范围手动参数。取值范围详见 :ref:`cnispFsWdrManual_t<cnispFsWdrManual_t>` 。

* stFsWdrAuto

  帧融合宽动态范围自动参数。取值范围详见 :ref:`cnispFsWdrAuto_t<cnispFsWdrAuto_t>` 。

* u8WdrNpLut[128]

  宽动态噪声特性查找表。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispWdrExposureAuto_t:

struct cnispWdrExposureAuto_t
------------------------------

**typedef struct cnispWdrExposureAuto**

**{**
  
  **cnU16_t u16ExposureRatioAdjustment[16][2];**

**} cnispWdrExposureAuto_t;**

宽动态曝光自动参数属性。

**成员说明**

* u16ExposureRatioAdjustment[16][2]

  增益-曝光率调整表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为曝光率调整，可取值为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispWdrExposureManual_t:

struct cnispWdrExposureManual_t
--------------------------------

**typedef struct cnispWdrExposureManual**

**{**
  
  **cnU32_t u32ManualExposureRatioMode;**

  **cnU32_t u32ExposureRatio;**

  **cnU32_t u32MAXExposureRatio;**

  **cnU32_t u32MaxClippedLong;**

  **cnU32_t u32TimeFilterER;**

  **cnU32_t u32LMExposureRatio;**

  **cnU32_t u32MSExposureRatio;**

  **cnU32_t u32SVSExposureRatio;**

**} cnispWdrExposureManual_t;**

宽动态曝光手动参数属性。

**成员说明**

* u32ManualExposureRatioMode

  使能手动曝光比功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32ExposureRatio

  曝光比。取值范围为[0x0,0xffff]。

* u32MAXExposureRatio

  曝光比最大值。取值范围为[0x0,0xffff]。

* u32MaxClippedLong

  长曝光时允许的最大裁剪像素百分比。取值范围为[0x0,0xff]。

* u32TimeFilterER

  曝光比的时域滤波。取值范围为[0x0,0xff]。

* u32LMExposureRatio

  中-长帧曝光比。取值范围为[0x0,0xfff]。

* u32MSExposureRatio

  中-短帧曝光比。取值范围为[0x0,0xfff]。

* u32SVSExposureRatio

  短-极短帧曝光比。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispWdrExposure_t:

struct cnispWdrExposure_t
--------------------------

**typedef struct cnispWdrExposure**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispWdrExposureAuto_t<cnispWdrExposureAuto_t>` **stWdrExposureAuto;**

  :ref:`cnispWdrExposureManual_t<cnispWdrExposureManual_t>` **stWdrExposureManual;**

**} cnispWdrExposure_t;**

宽动态曝光属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stWdrExposureAuto

  宽动态曝光自动参数。取值范围详见 :ref:`cnispWdrExposureAuto_t<cnispWdrExposureAuto_t>` 。

* stWdrExposureManual

  宽动态曝光手动参数。取值范围详见 :ref:`cnispWdrExposureManual_t<cnispWdrExposureManual_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispWdrNoiseProfile_t:

struct cnispWdrNoiseProfile_t
------------------------------

**typedef struct cnispWdrNoiseProfile**

**{**
  
  **cnU8_t u8VsWeightLut[128];**

  **cnU8_t u8SWeightLut[128];**

  **cnU8_t u8MWeightLut[128];**

  **cnU8_t u8LWeightLut[128];**

**} cnispWdrNoiseProfile_t;**

宽动态噪声特性属性。

**成员说明**

* u8VsWeightLut[128]

  极短帧权重表。取值范围为[0x0,0xff]。

* u8SWeightLut[128]

  短帧权重表。取值范围为[0x0,0xff]。

* u8MWeightLut[128]

  中帧权重表。取值范围为[0x0,0xff]。

* u8LWeightLut[128]

  长帧权重表。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispExposureManual_t:

struct cnispExposureManual_t
-----------------------------

**typedef struct cnispExposureManual**

**{**
  
  **cnU32_t u32ExposureTimeManual;**

  **cnU32_t u32SensorAgainManual;**

  **cnU32_t u32SensorDgainManual;**

  **cnU32_t u32IspDgainManual;**

  **cnU32_t u32ExposureTime;**

  **cnU32_t u32SensorAgain;**

  **cnU32_t u32SensorDgain;**

  **cnU32_t u32IspDgain;**

**} cnispExposureManual_t;**

曝光手动参数属性。

**成员说明**

* u32ExposureTimeManual

  使能曝光时间的手动设置。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32SensorAgainManual

  使能模拟增益的手动设置。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32SensorDgainManual

  使能数据增益的手动设置。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32IspDgainManual

  使能ISP数字增益的手动设置。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32ExposureTime

  手动设置的 Sensor 曝光时间。取值范围为[0x0,0xffffffff]。

* u32SensorAgain

  手动设置的 Sensor 模拟增益。取值范围为[0x400,0x40000]。

* u32SensorDgain

  手动设置的 Sensor 数字增益。取值范围为[0x400,0x8000)。

* u32IspDgain

  手动设置的 ISP 数字增益。取值范围为[0x400,0x8000)。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispExposureAuto_t:

struct cnispExposureAuto_t
---------------------------

**typedef struct cnispExposureAuto**

**{**
  
  **cnU32_t u32EnableAntiflicker;**

  **cnU32_t u32AntiflickerFrequency;**

  **cnU32_t u32AeConvergance;**

  **cnU32_t u32AeLdrTarget;**

  **cnU16_t u16AeHdrTarget[16][2];**

  **cnU32_t u32AeTailWeight;**

  **cnU32_t u32OfHighlightsPixels;**

  **cnU32_t u32HiTargetPrc;**

  **cnU32_t u32EnableIridixGlobalGain;**

  **cnU32_t u32AeTolerance;**

  **cnU8_t u8AeCorrection[16];**

  **cnU32_t u32AeExposureCorrection[16];**

**} cnispExposureAuto_t;**

曝光自动属性。

**成员说明**

* u32EnableAntiflicker

  使能抗闪功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32AntiflickerFrequency

  抗闪频率。取值范围为[0x0,0xff]。

* u32AeConvergance

  自动曝光收敛值。取值范围为[0x0,0xff]。

* u32AeLdrTarget

  自动曝光LDR目标值。取值范围为[0x0,0x3ff]。

* u16AeHdrTarget[16][2]

  自动曝光HDR目标值。取值范围为[0x0,0xffff]。

* u32AeTailWeight

  防裁剪尾部权重。取值范围为[0x0,0x400]。

* u32OfHighlightsPixels

  高亮区域像素阈值，控制高亮区域, 像素百分比必须低于高亮区域尾部百分比目标。取值范围为[0x0,0x64]。

* u32HiTargetPrc

  高亮区域尾部百分比目标。取值范围为[0x0,0x64]。

* u32EnableIridixGlobalGain

  使能高亮区域算法逻辑。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32AeTolerance

  曝光容差。取值范围为[0x0,0xffffffff]。

* u8AeCorrection[16]

  自动曝光校正值，定义了 AE_comp 值的 LUT 表。取值范围为[0x0,0xff]。

* u32AeExposureCorrection[16]

  自动曝光查找表，定义了 EV 对于 lux 值的 LUT 表。取值范围为[0x0,0xffffffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispExposure_t:

struct cnispExposure_t
-----------------------

**typedef struct cnispExposure**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU32_t u32ExposureValue;**

  **cnU32_t u32TotalGain;**

  **cnU32_t u32ManualExposureMode;**

  **cnU32_t u32MaxIntegrationTime;**

  **cnU32_t u32MaxSensorAgain;**

  **cnU32_t u32MaxSensorDgain;**

  **cnU32_t u32MaxIspDgain;**

  **cnU16_t u16ExposurePartitionLuts[2][10];**

  **cnU32_t u32AnalogGainLastPriority;**

  **cnU8_t u8Compensation;**

  :ref:`cnispExposureManual_t<cnispExposureManual_t>` **stExposureManual;**

  :ref:`cnispExposureAuto_t<cnispExposureAuto_t>` **stExposureAuto;**

**} cnispExposure_t;**

曝光属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u32ExposureValue

  曝光值。取值范围为[0x0,0xffffffff]，只读属性。

* u32TotalGain

  总计增益。取值范围为[0x0,0xffffffff]，只读属性。

* u32ManualExposureMode

  使能手动曝光模式。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能，只读属性。

* u32MaxIntegrationTime

  最大曝光时间阈值。取值范围为[0x0,0xffffffff]。

* u32MaxSensorAgain

  最大 sensor 模拟增益阈值。取值范围为[0x400,0x40000]。

* u32MaxSensorDgain

  最大 sensor 数字增益阈值。取值范围为[0x400,0x8000)。

* u32MaxIspDgain

  最大 ISP 数字增益阈值。取值范围为[0x400,0x8000)。

* u16ExposurePartitionLuts[2][10]

  曝光统计值表。取值范围为[0x0,0xffff]。

* u32AnalogGainLastPriority

  最低优先级的模拟增益。取值范围为[0x0,0xffffffff]。

* u8Compensation

  曝光补偿值。取值范围为[0x0,0xff]。

* stExposureManual

  曝光手动参数。取值范围详见 :ref:`cnispExposureManual_t<cnispExposureManual_t>` 。

* stExposureAuto

  曝光自动参数。取值范围详见 :ref:`cnispExposureAuto_t<cnispExposureAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispExposureInfo_t:

struct cnispExposureInfo_t
---------------------------

**typedef struct cnispExposureInfo**

**{**
  
  **cnU32_t u32ExposureTime;**

  **cnU32_t u32ExposureTime1;**

  **cnU32_t u32ExposureTime2;**

  **cnU32_t u32SensorAgain;**

  **cnU32_t u32SensorDgain;**

  **cnU32_t u32ISPDgain;**

  **cnU32_t u32ISO;**

  **cnU32_t u32WDRExposureRatio;**

  **cnU32_t u32FrameRate;**

  **cnU32_t u32ExposureValue;**

**} cnispExposureInfo_t;**

曝光统计信息属性。

**成员说明**

* u32ExposureTime

  曝光时间。取值范围为[0x0,0xffffffff]，只读属性。

* u32ExposureTime1

  曝光时间1。取值范围为[0x0,0xffffffff]，只读属性。

* u32ExposureTime2

  曝光时间2。取值范围为[0x0,0xffffffff]，只读属性。

* u32SensorAgain

  Sensor 的模拟增益。取值范围为[0x0,0xffffffff]，只读属性。

* u32SensorDgain

  Sensor 的数字增益。取值范围为[0x0,0xffffffff]，只读属性。

* u32ISPDgain

  ISP 的数字增益。取值范围为[0x0,0xffffffff]，只读属性。

* u32ISO

  ISO 值。取值范围为[0x0,0xffffffff]，只读属性。

* u32WDRExposureRatio

  WDR曝光比率。取值范围为[0x0,0xffffffff]，只读属性。

* u32FrameRate

  当前帧率。取值范围为[0x0,0xffff]，只读属性。

* u32ExposureValue

  当前曝光值。取值范围为[0x0,0xffffffff]，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeteringSetting_t:

struct cnispMeteringSetting_t
------------------------------

**typedef struct cnispMeteringSetting**

**{**
   
   **cnU32_t u32SkipX;**

   **cnU32_t u32OffsetX;**

   **cnU32_t u32SkipY;**

   **cnU32_t u32OffsetY;**

   **cnU32_t u32ScalBottom;**

   **cnU32_t u32ScaleTop;**

   **cnU32_t u32PlaneMode;**

   **cnU32_t u32NodesUsedHoriz;**

   **cnU32_t u32NodesUsedVert;**

 **} cnispMeteringSetting_t;**

统计设置属性。

**成员说明**

* u32SkipX

  水平提取间隔。取值范围为[0x0,0x7]，0x0为间隔2像素，0x1为间隔3像素，0x2为间隔4像素，0x3为间隔5像素，0x4为间隔8像素，[0x5,0x7]为间隔9像素。

* u32OffsetX

  水平提取偏移量。取值范围为[0x0,0x1]。

* u32SkipY

  垂直提取间隔。取值范围为[0x0,0x7]。

* u32OffsetY

  垂直提取偏移量。取值范围为[0x0,0x1]。

* u32ScalBottom

  底部比率。取值范围为[0x0,0xf]。

* u32ScaleTop

  顶部比率。取值范围为[0x0,0xf]。

* u32PlaneMode

  平面模式。取值范围为[0x0,0x7]。

* u32NodesUsedHoriz

  水平空间节点。取值范围为[0x0,0xff]。

* u32NodesUsedVert

  垂直空间节点。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeteringWgt_t:

struct cnispMeteringWgt_t
--------------------------

**typedef struct cnispMeteringWeight**

**{**
  
  **cnU8_t u8MeteringWeight[CN_M_METERING_LUT_LENGTH];**

**} cnispMeteringWgt_t;**

统计权重属性。

**成员说明**

* u8MeteringWeight

  统计权重表。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeteringInfo_t:

struct cnispMeteringInfo_t
---------------------------

**typedef struct cnispMeteringInfo**

**{**
  
  **cnU32_t u32TotalPixels;**

  **cnU32_t u32CountedPixels;**

  **cnU32_t u32PlaneTotal0;**

  **cnU32_t u32PlaneTotal1;**

  **cnU32_t u32PlaneTotal2;**

  **cnU32_t u32PlaneTotal3;**

  **cnU32_t u32PlanCounted0;**

  **cnU32_t u32PlanCounted1;**

  **cnU32_t u32PlanCounted2;**

  **cnU32_t u32PlanCounted3;**

  **cnU32_t u32Hist[** :ref:`M_HIST_NUMBER_1024 <1024>` **];**

  **cnU16_t u16Hist4[** :ref:`M_HIST_5_BIN <M_HIST_5_BIN>` **];**

**} cnispMeteringInfo_t;**

统计信息属性。

**成员说明**

* u32TotalPixels

  所有处理过的像素之和。取值范围为[0x0,0xffffffff]。

* u32CountedPixels

  非0权重的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlaneTotal0

  plane0 所有处理过的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlaneTotal1

  plane1 所有处理过的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlaneTotal2

  plane2 所有处理过的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlaneTotal3

  plane3 所有处理过的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlanCounted0

  plane0 非0权重的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlanCounted1

  plane1 非0权重的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlanCounted2

  plane2 非0权重的像素之和。取值范围为[0x0,0xffffffff]。

* u32PlanCounted3

  plane3 非0权重的像素之和。取值范围为[0x0,0xffffffff]。

* u32Hist[M_HIST_NUMBER_1024] 

  1024bin直方图。

* u16Hist4[M_HIST_5_BIN]

  5bin直方图。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMetering_t:

struct cnispMetering_t
-----------------------

**typedef struct cnispMetering**

**{**
  
  :ref:`cnispMeteringSetting_t<cnispMeteringSetting_t>` **stSetting;**

  :ref:`cnispMeteringWgt_t<cnispMeteringWgt_t>` **stMeteringWgt;**

  :ref:`cnispMeteringInfo_t<cnispMeteringInfo_t>` **stMeteringInfo;**

**} cnispMetering_t;**

统计属性。

**成员说明**

* stSetting

  统计设置。取值范围详见 :ref:`cnispMeteringSetting_t<cnispMeteringSetting_t>` 。

* stMeteringWgt

  统计权重。取值范围详见 :ref:`cnispMeteringWgt_t<cnispMeteringWgt_t>` 。

* stMeteringInfo

  统计信息。取值范围详见 :ref:`cnispMeteringInfo_t<cnispMeteringInfo_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbAttrManual_t:

struct cnispAwbAttrManual_t
----------------------------

**typedef struct cnispAwbAttrManual**

**{**
  
  **cnU32_t u32Gain00;**

  **cnU32_t u32Gain01;**

  **cnU32_t u32Gain10;**

  **cnU32_t u32Gain11;**

**} cnispAwbAttrManual_t;**

自动白平衡手动参数属性。

**成员说明**

* u32Gain00

  硬件通道00白平衡增益。取值范围为[0x0,0xfff]。

* u32Gain01

  硬件通道01白平衡增益。取值范围为[0x0,0xfff]。

* u32Gain10

  硬件通道10白平衡增益。取值范围为[0x0,0xfff]。

* u32Gain11

  硬件通道11白平衡增益。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbAttrAuto_t:

struct cnispAwbAttrAuto_t
--------------------------

**typedef struct cnispAwbAttrAuto**

**{**
  
  **cnU16_t u16BgMaxGain[16][2];**

  **cnU8_t u8AvgCoef;**

  **cnU16_t u16ZoneWghtVer[32];**

  **cnU16_t u16ZoneWghtHor[32];**

  **cnU16_t u16ColourPreference[4];**

  **cnU16_t u16HCCTPreference[3];**

  **cnU16_t u16MCCTPreference[3];**

  **cnU16_t u16LCCTPreference[3];**

  **cnU32_t u32MixLightParameters[9];**

  **cnU16_t u16LightSrc[8][2];**

  **cnU16_t u16RgPos[15];**

  **cnU16_t u16BgPos[15];**

  **cnU16_t u16SkyLuxTh;**

  **cnU16_t u16WbStrengthMult[3];**

  **cnU16_t u16WbStatic[4];**

  **cnU16_t u16ColorTemp[12];**

  **cnU16_t u16CtRgPosCalc[12];**

  **cnU16_t u16CtBgPosCalc[12];**

  **cnU16_t u16CtD65Pos;**

  **cnU16_t u16CtD40Pos;**

  **cnU16_t u16CtD30Pos;**

  **cnU8_t u8EvtoluxProbabilityEnable;**

  **cnU32_t u32EvtoluxEvLut[17];**

  **cnU32_t u32EvtoluxLuxLut[17];**

  **cnU16_t u16RgbWeight[15][15];**

  **cnU16_t u16LightSrcWeight[15][15];**

  **cnU16_t u16ColorTempMesh[15][15];**

**} cnispAwbAttrAuto_t;**

自动白平衡自动参数属性。

**成员说明**

* u16BgMaxGain[16][2]

  增益-B增益最大值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为B增益最大值，可取值为[0x0,0xffff]。

* u8AvgCoef

  平均系数。取值范围为[0x0,0xff]。

* u16ZoneWghtVer[32]

  垂直区域权重表。取值范围为[0x0,0xffff]。

* u16ZoneWghtHor[32]

  水平区域权重表。取值范围为[0x0,0xffff]。

* u16ColourPreference[4]

  颜色偏好模型的阈值表。取值范围为[0x0,0xffff]。

* u16HCCTPreference[3]

  高色温红色和绿色参考值。取值范围为[0x0,0xffff]。

* u16MCCTPreference[3]

  中色温红色和绿色参考值。取值范围为[0x0,0xffff]。

* u16LCCTPreference[3]

  低色温红色和绿色参考值。取值范围为[0x0,0xffff]。

* u32MixLightParameters[9]

  混合光源阈值表，检测混合光源的触发条件。取值范围为[0x0,0xffff]。

* u16LightSrc[8][2]

  额外光源坐标。取值范围为[0x0,0xffff]。

* u16RgPos[15]

  R/G光源的位置。取值范围为[0x0,0xffff]。

* u16BgPos[15]

  B/G光源的位置。取值范围为[0x0,0xffff]。

* u16SkyLuxTh

  自然光的亮度阈值。取值范围为[0x0,0xffff]。

* u16WbStrengthMult[3]

  白平衡强度系数。取值范围为[0x0,0xffff]。

* u16WbStatic[4]

  白平衡静态参数。取值范围为[0x0,0xffff]。

* u16ColorTemp[12]

  色温范围表。取值范围为[0x0,0xffff]。

* u16CtRgPosCalc[12]

  给定色温的 R/G 值。取值范围为[0x0,0xffff]。

* u16CtBgPosCalc[12]

  给定色温的 B/G 值。取值范围为[0x0,0xffff]。

* u16CtD65Pos

  D65 色温光源位置。取值范围为[0x0,0xffff]，只读属性。

* u16CtD40Pos

  D40 色温光源位置。取值范围为[0x0,0xffff]，只读属性。

* u16CtD30Pos

  D30 色温光源位置。取值范围为[0x0,0xffff]，只读属性。

* u8EvtoluxProbabilityEnable

  使能 EV2lux 功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32EvtoluxEvLut[17]

  EV2lux 的 ev（曝光值） 表。取值范围为[0x0,0xffffffff]。

* u32EvtoluxLuxLut[17]

  EV2lux 的 lux（亮度）表。取值范围为[0x0,0xffffffff]。

* u16RgbWeight[15][15]

  RGB增益-权重表，取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为权重，可取值为[0x0,0xffff]。

* u16LightSrcWeight[15][15]

  光源增益-权重表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为权重，可取值为[0x0,0xffff]。

* u16ColorTempMesh[15][15]

  增益-色温表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为色温表，可取值为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbAttr_t:

struct cnispAwbAttr_t
----------------------

**typedef struct cnispAwbAttr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispAwbAttrManual_t<cnispAwbAttrManual_t>` **stAwbAttrManual;**

  :ref:`cnispAwbAttrAuto_t<cnispAwbAttrAuto_t>` **stAwbAttrAuto;**

**} cnispAwbAttr_t;**

自动白平衡属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stAwbAttrManual

  自动白平衡手动参数。取值范围详见 :ref:`cnispAwbAttrManual_t<cnispAwbAttrManual_t>` 。

* stAwbAttrAuto

  自动白平衡自动参数。取值范围详见 :ref:`cnispAwbAttrAuto_t<cnispAwbAttrAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbInfo_t:

struct cnispAwbInfo_t
----------------------

**typedef struct cnispAwbInfo**

**{**
  
  **cnU32_t u32GainR;**

  **cnU32_t u32GainGr;**

  **cnU32_t u32GainGb;**

  **cnU32_t u32GainB;**

  **cnU32_t u32ColorTemp;**

**} cnispAwbInfo_t;**

自动白平衡信息属性。

**成员说明**

* u32GainR

  R通道增益。取值范围为[0x0,0xffff]，只读属性。

* u32GainGr

  Gr通道增益。取值范围为[0x0,0xffff]，只读属性。

* u32GainGb

  Gb通道增益。取值范围为[0x0,0xffff]，只读属性。

* u32GainB

  B通道增益。取值范围为[0x0,0xffff]，只读属性。

* u32ColorTemp
  
  色温。取值范围为[0x0,0xffff]，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCcmInfo_t:

struct cnispCcmInfo_t
----------------------

**typedef struct cnispCcmInfo**

**{**
  
  **cnU32_t u32CoefftRR;**

  **cnU32_t u32CoefftRG;**

  **cnU32_t u32CoefftRB;**

  **cnU32_t u32CoefftGR;**

  **cnU32_t u32CoefftGG;**

  **cnU32_t u32CoefftGB;**

  **cnU32_t u32CoefftBR;**

  **cnU32_t u32CoefftBG;**

  **cnU32_t u32CoefftBB;**

**} cnispCcmInfo_t;**

颜色校正信息属性。

**成员说明**

* u32CoefftRR

  RR系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftRG

  RG系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftRB

  RB系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftGR

  GR系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftGG

  GG系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftGB

  GB系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftBR

  BR系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftBG

  BG系数。取值范围为[0x0,0xffff]，只读属性。

* u32CoefftBB

  BB系数。取值范围为[0x0,0xffff]，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispWbInfo_t:

struct cnispWbInfo_t
---------------------

**typedef struct cnispWbInfo**

**{**

  :ref:`cnispAwbInfo_t<cnispAwbInfo_t>` **stAwbInfo;**

  :ref:`cnispCcmInfo_t<cnispCcmInfo_t>` **stCcmInfo;**

**} cnispWbInfo_t;**

白平衡信息属性。

**成员说明**

* stAwbInfo

  白平衡信息。取值范围详见 :ref:`cnispAwbInfo_t<cnispAwbInfo_t>` 。

* stCcmInfo

  颜色校正信息。取值范围详见 :ref:`cnispCcmInfo_t<cnispCcmInfo_t>` ，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbMeteringSetting_t:

struct cnispAwbMeteringSetting_t
---------------------------------

**typedef struct cnispAwbMeteringSetting**

**{**
  
  **cnU8_t u8StatsMode;**

  **cnU32_t u32WhiteLevelAwb;**

  **cnU32_t u32BlackLevelAwb;**

  **cnU32_t u32CrRefMaxAwb;**

  **cnU32_t u32CrRefMinAwb;**

  **cnU32_t u32CbRefMaxAwb;**

  **cnU32_t u32CbRefMinAwb;**

  **cnU32_t u32NodesUsedHoriz;**

  **cnU32_t u32NodesUsedVert;**

  **cnU32_t u32CrRefHighAwb;**

  **cnU32_t u32CrRefLowAwb;**

  **cnU32_t u32CbRefHighAwb;**

  **cnU32_t u32CbRefLowAwb;**

**} cnispAwbMeteringSetting_t;**

白平衡统计配置属性。

**成员说明**

* u8StatsMode

  统计模式选择。取值范围为[0x0,0x1]，0x0为（G/R,B/R），0x1为（R/G, B/G）。

* u32WhiteLevelAwb

  最大有效数据临界值。取值范围为[0x0,0x3ff]。

* u32BlackLevelAwb

  最小有效数据临界值。取值范围为[0x0,0x3ff]。

* u32CrRefMaxAwb

  白色区域Cr（R/G）最大值。取值范围为[0x0,0xfff]。

* u32CrRefMinAwb

  白色区域Cr（R/G）最小值。取值范围为[0x0,0xfff]。

* u32CbRefMaxAwb

  白色区域Cb（B/G）最大值。取值范围为[0x0,0xfff]。

* u32CbRefMinAwb

  白色区域Cb（B/G）最小值。取值范围为[0x0,0xfff]。

* u32NodesUsedHoriz

  水平方向使用的节点。取值范围为[0x0,0xff]。

* u32NodesUsedVert

  垂直方向使用的节点。取值范围为[0x0,0xff]。

* u32CrRefHighAwb

  白色区域Cr高值。取值范围为[0x0,0xfff]。

* u32CrRefLowAwb

  白色区域Cr低值。取值范围为[0x0,0xfff]。

* u32CbRefHighAwb

  白色区域Cb高值。取值范围为[0x0,0xfff]。

* u32CbRefLowAwb

  白色区域Cb低值。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbMeteringZone_t:

struct cnispAwbMeteringZone_t
------------------------------

**typedef struct cnispAwbMeteringZone**

**{**
  
  **cnU16_t u16Rg;**

  **cnU16_t u16Bg;**

  **cnU32_t u32Sum;**

**} cnispAwbMeteringZone_t;**

白平白衡矩阵区域统计属性。

**成员说明**

* u16Rg

  静态 AWB R/G 比率。取值范围为[0x0,0xfff]。

* u16Bg

  静态 AWB B/G 比率。取值范围为[0x0,0xfff]。

* u32Sum

  静态 AWB 像素之和。取值范围为[0x0,0xffffffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbMeteringInfo_t:

struct cnispAwbMeteringInfo_t
------------------------------

**typedef struct cnispAwbMeteringInfo**

**{**
  
  :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` **stGlobalStat;**

  :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` **astLocalStat[** :ref:`M_AWB_MAX_ZONE_NUMBER <M_AWB_MAX_ZONE_NUMBER>` **];**

  :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` **stDynamic;**

**} cnispAwbMeteringInfo_t;**

白平衡矩阵统计信息属性。

**成员说明**

* stGlobalStat

  全局状态。取值范围详见 :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` 。

* astLocalStat[M_AWB_MAX_ZONE_NUMBER]

  局部状态。取值范围详见 :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` 。

* stDynamic

  动态属性。取值范围详见 :ref:`cnispAwbMeteringZone_t<cnispAwbMeteringZone_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAwbMetering_t:

struct cnispAwbMetering_t
--------------------------

**typedef struct cnispAwbMetering**

**{**
  
  :ref:`cnispAwbMeteringSetting_t<cnispAwbMeteringSetting_t>` **stSetting;**

  **cnU8_t u8Weight[** :ref:`M_AWB_MAX_ZONE_NUMBER <M_AWB_MAX_ZONE_NUMBER>` **];**

  :ref:`cnispAwbMeteringInfo_t<cnispAwbMeteringInfo_t>` **stAwbMeteringInfo;**

**} cnispAwbMetering_t;**

白平衡矩阵统计属性。

**成员说明**

* stSetting

  白平衡矩阵配置。取值范围详见 :ref:`cnispAwbMeteringSetting_t<cnispAwbMeteringSetting_t>` 。

* u8Weight[M_AWB_MAX_ZONE_NUMBER]

  权重配表。取值范围为[0x0,0xf]。

* stAwbMeteringInfo

  白平衡矩阵信息。取值范围详见 :ref:`cnispAwbMeteringInfo_t<cnispAwbMeteringInfo_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispSquare_t:

struct cnispSquare_t
---------------------

**typedef struct cnispSquare**

**{**
  
  **cnU32_t u32SqrtIn;**

  **cnU32_t u32SqrtOut;**

  **cnU32_t u32RootIn;**

  **cnU32_t u32RootOut;**

**} cnispSquare_t;**

开平方根属性。

**成员说明**

* u32SqrtIn

  平方根运算的输入。取值范围为[0x0,0xfffff]。

* u32SqrtOut

  平方根运算的输出。取值范围为[0x0,0xffff]。

* u32RootIn

  平方运算的输入。取值范围为[0x0,0xffff]。

* u32RootOut

  平方运算的输出。取值范围为[0x0,0xfffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGe_t:

struct cnispGe_t
-----------------

**typedef struct cnispGe**

**{**
  
  **cnU8_t u8GeEnable;**

  **cnU8_t u8GeStrength;**

  **cnU16_t u16GeSlope;**

  **cnU16_t u16GeThreshold;**

  **cnU8_t u8GeSens;**

  **cnU8_t u8DebugSel;**

**} cnispGe_t;**

绿平衡属性。

**成员说明**

* u8GeEnable

  使能绿平衡功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8GeStrength

  绿平衡强度。取值范围为[0x0,0xff]。

* u16GeSlope

  绿平衡斜率。取值范围为[0x0,0xfff]。

* u16GeThreshold

  绿平衡阈值。取值范围为[0x0,0xffff]。

* u8GeSens

  边缘绿平衡灵敏度。取值范围为[0x0,0xff]。

* u8DebugSel

  调试开关。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDpcAuto_t:

struct cnispDpcAuto_t
----------------------

**typedef struct cnispDpcAuto**

**{**
  
  **cnU16_t u16DpSlope[16][2];**

  **cnU16_t u16DpThreshold[16][2];**

  **cnU16_t u16DpBlend[16][2];**

**} cnispDpcAuto_t;**

动态坏点校正自动参数属性。

**成员说明**

* u16DpSlope[16][2]

  动态坏点校正增益-斜率表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为斜率，可取值为[0x0,0xfff]。

* u16DpThreshold[16][2]

  动态坏点校正增益-阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值，可取值为[0x0,0xfff]。

* u16DpBlend[16][2]

  动态坏点校正增益-混合项表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为混合项，可取值为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDpc_t:

struct cnispDpc_t
------------------

**typedef struct cnispDpc**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU8_t u8DpEnable;**

  **cnU8_t u8DarkDisable;**

  **cnU8_t u8BrightDisable;**

  **cnU8_t u8ShowStdefectPixel;**

  **cnU8_t u8DebugSel;**

  **cnU32_t u32DpSlope;**

  **cnU32_t u32DpThreshold;**

  **cnU32_t u32DpdevThreshold;**

  **cnU32_t u32DpBlend;**

  **cnU32_t u32LineThresh;**

  **cnU32_t u32SigmaLn;**

  **cnU32_t u32ThreshShort;**

  **cnU32_t u32ThreshLong;**

  :ref:`cnispDpcAuto_t<cnispDpcAuto_t>` **stAuto;**

**} cnispDpc_t;**

动态坏点校正属性

**成员说明**

* enOpType

  调节类型；取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u8DpEnable

  使能坏点校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8DarkDisable

  去使能暗点检测功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8BrightDisable

  去使能亮点检测功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8ShowStdefectPixel

  使能静止坏点显示功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8DebugSel

  使能调试功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32DpSlope

  坏点校正强度的斜率。取值范围为[0x0,0xfff]。

* u32DpThreshold

  坏点校正强度的阈值。取值范围为[0x0,0xfff]。

* u32DpdevThreshold

  边缘坏点检测灵敏度。取值范围为[0x0,0xffff]。

* u32DpBlend

  混合的定向和非定向控制。取值范围为[0x0,0xff]，0x0：无方向，0xff: 有方向。

* u32LineThresh

  边缘附近的坏点校正的方向性。取值范围为[0x0,0xffff]。

* u32SigmaLn

  噪声强度的手动覆盖值。取值范围为[0x0,0xffff]。

* u32ThreshShort

  短帧噪声阈值。取值范围为[0x0,0xff]。

* u32ThreshLong

  长帧噪声阈值。取值范围为[0x0,0xff]。

* stAuto

  坏点校正自动参数。取值范围详见 :ref:`cnispDpcAuto_t<cnispDpcAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBnrNp_t:

struct cnispBnrNp_t
--------------------

**typedef struct cnispBnrNp**

**{**
  
  **cnU8_t u8UseLut;**

  **cnU32_t u32UseExpMask;**

  **cnU32_t u32BlackReflect;**

  **cnU32_t u32GlobalOffset;**

  **cnU32_t u32BlackLevel;**

  **cnU32_t u32NoiseProfileThresh1;**

  **cnU32_t u32NoiseProfileThresh2;**

  **cnU32_t u32NoiseProfileThresh3;**

  **cnU32_t u32NoiseLevel0;**

  **cnU32_t u32NoiseLevel1;**

  **cnU32_t u32NoiseLevel2;**

  **cnU32_t u32NoiseLevel3;**

  **cnU8_t u8WeightLut[128];**

**} cnispBnrNp_t;**

拜耳域降噪特性属性。

**成员说明**

* u8UseLut

  使能查找表功能。取值范围为[0x0,0x1]，1：使用查找表数据, 0：使用曝光掩码、帧拼接或阈值。

* u32UseExpMask

  使能曝光掩码功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能，使用 FSWDR 提供的掩码。

* u32BlackReflect

  低于黑电平的电平值处理选择项。取值范围为[0x0,0x1]，0x0为设置为0，0x1为反射。

* u32GlobalOffset

  全局偏移量。取值范围为[0x0,0xff]。

* u32BlackLevel

  黑电平值。取值范围为[0x0,0xffff]。

* u32NoiseProfileThresh1

  曝光阈值1，用来判断像素来源于极短帧还是短帧。取值范围为[0x0,0xffff]。

* u32NoiseProfileThresh2

  曝光阈值2，用来判断像素来源于中帧还是短帧。取值范围为[0x0,0xffff]。

* u32NoiseProfileThresh3

  曝光阈值3，用来判断像素来源于中帧还是长帧。取值范围为[0x0,0xffff]。

* u32NoiseLevel0

  极短帧噪声水平值。取值范围为[0x0,0xff]。

* u32NoiseLevel1

  短帧噪声水平值。取值范围为[0x0,0xff]。

* u32NoiseLevel2

  中帧噪声水平值。取值范围为[0x0,0xff]。

* u32NoiseLevel3

  长帧噪声水平值。取值范围为[0x0,0xff]。

* u8WeightLut[128]

  权重查找表。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBnrAuto_t:

struct cnispBnrAuto_t
----------------------

**typedef struct cnispBnrAuto**

**{**
  
  **cnU16_t u16ScaleStrength[16][2];**

  **cnU16_t u16ScaleStrength1[16][2];**

  **cnU16_t u16IntConfig[16][2];**

  **cnU16_t u16Thresh1[16][2];**

  **cnU16_t u16Thresh4[16][2];**

  **cnU16_t u16SadFiltThresh[16][2];**

  **cnU16_t u16StrengthMcContrast[16][2];**

**} cnispBnrAuto_t;**

拜耳域自动参数属性。

**成员说明**

* u16ScaleStrength[16][2]

  增益-自动模式下低频降噪强度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为强度，可取值为[0x0,0xffff]。

* u16ScaleStrength1[16][2]

  增益-自动模式下高频降噪强度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为强度，可取值为[0x0,0xffff]。

* u16IntConfig[16][2]

  增益-强度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为强度，可取值为[0x0,0xffff]。

* u16Thresh1[16][2]

  增益-高频噪声阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值1，可取值为[0x0,0xffff]。

* u16Thresh4[16][2]

  增益-低频噪声阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值4，可取值为[0x0,0xffff]。

* u16SadFiltThresh[16][2]

  增益-非局部均值强度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为非局部均值强度，可取值为[0x0,0xffff]。

* u16StrengthMcContrast[16][2]

  增益-对比度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为对比度，可取值为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBnr_t:

struct cnispBnr_t
------------------

**typedef struct cnispBnr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU8_t u8BnrEnable;**

  **cnU8_t u8ViewFilter;**

  **cnU8_t u8ScaleMode;**

  **cnU8_t u8FilterSelect;**

  **cnU8_t u8IntSelect;**

  **cnU8_t u8RmEnable;**

  **cnU32_t u32RmCenterX;**

  **cnU32_t u32RmCenterY;**

  **cnU32_t u32RmOffCenterMult;**

  **cnU8_t u8RmShadingLt[33];**

  **cnU32_t u32IntConfig;**

  **cnU8_t u8NlmEn;**

  **cnU32_t u32NonlinearWkgen;**

  **cnU32_t u32SadFiltThresh;**

  **cnU32_t u32Thresh1h;**

  **cnU32_t u32Thresh4h;**

  **cnU32_t u32Strength1;**

  **cnU32_t u32Strength4;**

  :ref:`cnispBnrNp_t<cnispBnrNp_t>` **stBnrNp;**

  :ref:`cnispBnrAuto_t<cnispBnrAuto_t>` **stAuto;**

**} cnispBnr_t;**

拜耳域降噪属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u8BnrEnable

  使能拜耳域降噪功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8ViewFilter

  调试模式使用。取值范围为[0x0,0x3]。

* u8ScaleMode

  调试模式使用。取值范围为[0x0,0x3]。

* u8FilterSelect

  细调选择。取值范围为[0x0,0x1]，只读属性。

* u8IntSelect

  调试强度选择。取值范围为[0x0,0x1]，只读属性。

* u8RmEnable

  使能降噪强度与 Shading 联动功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32RmCenterX

  Shading map（阴影图） x轴中心坐标。取值范围为[0x0,0xffff]。

* u32RmCenterY

  Shading map（阴影图）y轴中心坐标。取值范围为[0x0,0xffff]。

* u32RmOffCenterMult

  Radial 表归一化系数。取值范围为[0x0,0xffff]。

* u8RmShadingLt[33]

  Radial 特性查找表。取值范围为[0x0,0xff]。

* u32IntConfig

  强度配置，原图与 intensity filter 的融合系数。取值范围为[0x0,0xf]。

* u8NlmEn

  使能非局部均值滤波。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32NonlinearWkgen

  使能非线性权重迭代功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32SadFiltThresh

  非局部均值过滤阈值。取值范围为[0x0,0xff]。

* u32Thresh1h

  水平滤波高频噪声阈值。取值范围为[0x0,0xff]。

* u32Thresh4h

  水平滤波低频噪声阈值。取值范围为[0x0,0xff]。

* u32Strength1

  高频噪声强度。取值范围为[0x0,0xff]。

* u32Strength4

  低频噪声强度。取值范围为[0x0,0xff]。

* stBnrNp

  拜耳域噪声特性。取值范围为详见 :ref:`cnispBnrNp_t<cnispBnrNp_t>` 。

* stAuto

  拜耳域自动参数。取值范围为详见 :ref:`cnispBnrAuto_t<cnispBnrAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBnrLut_t:

struct cnispBnrLut_t
---------------------

**typedef struct cnispBnrLut**

**{**
  
  **cnU8_t u8RmShadingLt[33];**

  **cnU8_t u8WeightLut[128];**

**} cnispBnrLut_t;**

拜耳域降噪查找表属性。

**成员说明**

* u8RmShadingLt[33]

  同轴圆噪声模型查找表。取值范围为[0x0,0xff]。

* u8WeightLut[128]

  标定后的噪声模型权重查找表，影响多尺度滤波的强度。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCac_t:

struct cnispCac_t
------------------

**typedef struct cnispCac**

**{**
  
  **cnU8_t u8CaEnable;**

  **cnU32_t u32MeshScale;**

  **cnU32_t u32MeshWidth;**

  **cnU32_t u32MeshHeight;**

  **cnU32_t u32LineOffset;**

  **cnU32_t u32PlaneOffset;**

  **cnU32_t u32MeshReload;**

  **cnU32_t u32CaFilterMem[32];**

  **cnU16_t u16CaCorrection[3];**

  **cnU16_t u16CaCorrectionMem[4][10];**

**} cnispCac_t;**

色差校正属性。

**成员说明**

* u8CaEnable

  使能色差校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32MeshScale

  网格数据额外偏移量。取值范围为[0x0,0x3]。

* u32MeshWidth

  网格宽度。取值范围为[0x0,0x7f]。

* u32MeshHeight

  网格高度。取值范围为[0x0,0x7f]。

* u32LineOffset

  网格之间的偏移量。取值范围为[0x0,0x1fff]。

* u32PlaneOffset

  颜色通道之间的偏移量。取值范围为[0x0,0x1fff]。

* u32MeshReload

  使能网格重新加载功能。取值范围为[0x0,0x1]，0x0为不重新加载，0x1为重新加载。

* u32CaFilterMem[32]

  色差滤波内存。取值范围为[0x0,0xffffffff]。

* u16CaCorrection[3]

  色差校正。取值范围为[0x0,0xffff]。

* u16CaCorrectionMem[4][10]

  色差校正内存。取值范围为[0x0,0xffffffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBlcManual_t:

struct cnispBlcManual_t
------------------------

**typedef struct cnispBlcManual**

**{**
  
  **cnU32_t u32Offset00;**

  **cnU32_t u32Offset01;**

  **cnU32_t u32Offset10;**

  **cnU32_t u32Offset11;**

**} cnispBlcManual_t;**

黑电平校正手动参数属性。

**成员说明**

* u32Offset00

  黑电平校正矩阵通道00偏移量。取值范围为[0x0,0xfff]。

* u32Offset01

  黑电平校正矩阵通道01偏移量。取值范围为[0x0,0xfff]。

* u32Offset10

  黑电平校正矩阵通道10偏移量。取值范围为[0x0,0xfff]。

* u32Offset11

  黑电平校正矩阵通道11偏移量。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBlcAuto_t:

struct cnispBlcAuto_t
----------------------

**typedef struct cnispBlcAuto**

**{**
  
  **cnU16_t u16Offset00[16][2];**

  **cnU16_t u16Offset01[16][2];**

  **cnU16_t u16Offset10[16][2];**

  **cnU16_t u16Offset11[16][2];**

**} cnispBlcAuto_t;**

黑电平校正自动参数属性。

**成员说明**

* u16Offset00[16][2]

  黑电平校正矩阵00增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xffff]。 

* u16Offset01[16][2]

  黑电平校正矩阵01增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xffff]。 

* u16Offset10[16][2]

  黑电平校正矩阵10增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xffff]。 

* u16Offset11[16][2]

  黑电平校正矩阵11增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xffff]。 

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispBlc_t:

struct cnispBlc_t
------------------

**typedef struct cnispBlc**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispBlcManual_t<cnispBlcManual_t>` **stManual;**

  :ref:`cnispBlcAuto_t<cnispBlcAuto_t>` **stAuto;**

**} cnispBlc_t;**

黑电平校正属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stManual

  黑电平校正手动参数。取值范围详见 :ref:`cnispBlcManual_t<cnispBlcManual_t>` 。

* stAuto

  黑电平校正自动参数。取值范围详见 :ref:`cnispBlcAuto_t<cnispBlcAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispRadialShading_t:

struct cnispRadialShading_t
----------------------------

**typedef struct cnispRadialShading**

**{**
  
  **cnU8_t u8RadialEnable;**

  **cnU16_t u16CenterRX;**

  **cnU16_t u16CenterRY;**

  **cnU16_t u16CenterGX;**

  **cnU16_t u16CenterGY;**

  **cnU16_t u16CenterBX;**

  **cnU16_t u16CenterBY;**

  **cnU16_t u16OffCenterMultRx;**

  **cnU16_t u16OffCenterMultRy;**

  **cnU16_t u16OffCenterMultGx;**

  **cnU16_t u16OffCenterMultGy;**

  **cnU16_t u16OffCenterMultBx;**

  **cnU16_t u16OffCenterMultBy;**

  **cnU16_t u16OffCenterMultlRx;**

  **cnU16_t u16OffCenterMultlRy;**

**} cnispRadialShading_t;**

同轴圆阴影校正属性。

**成员说明**

* u8RadialEnable

  使能同轴圆阴影校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u16CenterRX

  红色阴影图的x轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterRY

  红色阴影图的y轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterGX

  绿色阴影图的x轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterGY

  绿色阴影图的y轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterBX

  蓝色阴影图的x轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterBY

  蓝色阴影图的y轴中心坐标。取值范围为[0x0,0xffff]。

* u16OffCenterMultRx

  红色通道中心边缘间距x轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultRy

  红色通道中心边缘间距y轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultGx

  绿色通道中心边缘间距x轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultGy

  绿色通道中心边缘间距y轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultBx

  蓝色通道中心边缘间距x轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultBy

  蓝色通道中心边缘间距y轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultlRx

  红外通道中心边缘间距x轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

* u16OffCenterMultlRy

  红外通道中心边缘间距y轴归一化系数，控制shading map 与图像边缘的缩放比例。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispRadialShadingLut_t:

struct cnispRadialShadingLut_t
-------------------------------

**typedef struct cnispRadialShadingLut**

**{**
  
  **cnU32_t u32RadialDataR[129];**

  **cnU32_t u32RadialDataG[129];**

  **cnU32_t u32RadialDataB[129];**

**} cnispRadialShadingLut_t;**

同轴圆阴影校正查找表。

**成员说明**

* u32RadialDataR[129]

  红色通道同轴圆配置项。取值范围为[0x0,0xffff]。

* u32RadialDataG[129]

  绿色通道同轴圆配置项。取值范围为[0x0,0xffff]。

* u32RadialDataB[129]

  蓝色通道同轴圆配置项。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeshShadingManual_t:

struct cnispMeshShadingManual_t
--------------------------------

**typedef struct cnispMeshShadingManual**

**{**
  
  **cnU8_t u8MeshEnable;**

  **cnU8_t u8MeshShow;**

  **cnU8_t u8MeshScale;**

  **cnU8_t u8MeshAlphaMode;**

  **cnU32_t u32MeshStrength;**

  **cnU32_t u32MeshPageR;**

  **cnU32_t u32MeshPageG;**

  **cnU32_t u32MeshPageB;**

  **cnU32_t u32MeshPageIr;**

  **cnU32_t u32MeshWidth;**

  **cnU32_t u32MeshHeight;**

  **cnU32_t u32MeshReload;**

  **cnU32_t u32MeshAlphaBankR;**

  **cnU32_t u32MeshAlphaBankG;**

  **cnU32_t u32MeshAlphaBankB;**

  **cnU32_t u32MeshAlphaBankIr;**

  **cnU32_t u32MeshAlphaR;**

  **cnU32_t u32MeshAlphaG;**

  **cnU32_t u32MeshAlphaB;**

  **cnU32_t u32MeshAlphaIr;**

**} cnispMeshShadingManual_t;**

网格阴影校正手动参数属性。

**成员说明**

* u8MeshEnable

  使能网格阴影校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8MeshShow

  使能网格数据展示功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8MeshScale

  网格模式的精度和最大增益。取值范围为[0x0,0x7]。

* u8MeshAlphaMode

  Alpha 混合模式。取值范围为[0x0,0x2]。

* u32MeshStrength

  网格强度。取值范围为[0x0,0xffff]。

* u32MeshPageR

  红色网格内存页选择属性。取值范围为[0x0,0x3]。

* u32MeshPageG

  绿色网格内存页选择属性。取值范围为[0x0,0x3]。

* u32MeshPageB

  蓝色网格内存页选择属性。取值范围为[0x0,0x3]。

* u32MeshPageIr

  红外网格内存页选择属性。取值范围为[0x0,0x3]。

* u32MeshWidth

  网格宽度。取值范围为[0x0,0x3f]。

* u32MeshHeight

  网格高度。取值范围为[0x0,0x3f]。

* u32MeshReload

  网格缓存重新加载属性。取值范围为[0x0,0x1]，0x0为不重新加载，0x1为重新加载。

* u32MeshAlphaBankR

  红色alpha混合bank选择属性。取值范围为[0x0,0x5]。

* u32MeshAlphaBankG

  绿色alpha混合bank选择属性。取值范围为[0x0,0x5]。

* u32MeshAlphaBankB

  蓝色alpha混合bank选择属性。取值范围为[0x0,0x5]。

* u32MeshAlphaBankIr

  红外alpha混合bank选择属性。取值范围为[0x0,0x5]。

* u32MeshAlphaR

  红色alpha混合系数。取值范围为[0x0,0xff]。

* u32MeshAlphaG

  绿色alpha混合系数。取值范围为[0x0,0xff]。

* u32MeshAlphaB

  蓝色alpha混合系数。取值范围为[0x0,0xff]。

* u32MeshAlphaIr

  红外alpha混合系数。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeshShadingAuto_t:

struct cnispMeshShadingAuto_t
------------------------------

**typedef struct cnispMeshShadingAuto**

**{**
  
  **cnU16_t u16MeshStrength[16][2];**

**} cnispMeshShadingAuto_t;**

网格阴影校正自动参数属性。

**成员说明**

* u16MeshStrength[16][2]

  网格阴影校正增益-强度表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为强度，可取值为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeshShading_t:

struct cnispMeshShading_t
--------------------------

**typedef struct cnispMeshShading**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispMeshShadingManual_t<cnispMeshShadingManual_t>` **stManual;**

  :ref:`cnispMeshShadingAuto_t<cnispMeshShadingAuto_t>` **stAuto;**

**} cnispMeshShading_t;**

网格阴影校正属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stManual

  网格阴影校正手动参数。取值范围详见 :ref:`cnispMeshShadingManual_t<cnispMeshShadingManual_t>` 。

* stAuto

  网格阴影校正自动参数。取值范围详见 :ref:`cnispMeshShadingAuto_t<cnispMeshShadingAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispShadingLut_t:

struct cnispShadingLut_t
-------------------------

**typedef struct cnispShadingLut**

**{**
  
  **cnU8_t u8RGain[** :ref:`CN_M_ISP_LSC_GRID_POINTS_EX <CN_M_ISP_LSC_GRID_POINTS_EX>` **];**

  **cnU8_t u8GGain[** :ref:`CN_M_ISP_LSC_GRID_POINTS_EX <CN_M_ISP_LSC_GRID_POINTS_EX>` **];**

  **cnU8_t u8BGain[** :ref:`CN_M_ISP_LSC_GRID_POINTS_EX <CN_M_ISP_LSC_GRID_POINTS_EX>` **];**

**} cnispShadingLut_t;**

阴影校正查找表。

**成员说明**

* u8RGain[CN_M_ISP_LSC_GRID_POINTS_EX]

  红色增益。取值范围为[0x0,0xff]。

* u8GGain[CN_M_ISP_LSC_GRID_POINTS_EX]

  绿色增益。取值范围为[0x0,0xff]。

* u8BGain[CN_M_ISP_LSC_GRID_POINTS_EX]

  蓝色增益。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispMeshShadingLut_t:

struct cnispMeshShadingLut_t
-----------------------------

**typedef struct cnispMeshShadingLut**

**{**
  
  :ref:`cnispShadingLut_t<cnispShadingLut_t>` **stHigh;**

  :ref:`cnispShadingLut_t<cnispShadingLut_t>` **stMed;**

  :ref:`cnispShadingLut_t<cnispShadingLut_t>` **stLow;**

**} cnispMeshShadingLut_t;**

网格阴影校正查找表。

**成员说明**

* stHigh

  高色温网格阴影校正查找表。取值范围详见 :ref:`cnispShadingLut_t<cnispShadingLut_t>` 。

* stMed

  中色温网格阴影校正查找表。取值范围详见 :ref:`cnispShadingLut_t<cnispShadingLut_t>` 。

* stLow

  低色温网格阴影校正查找表。取值范围详见 :ref:`cnispShadingLut_t<cnispShadingLut_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDrcGain_t:

struct cnispDrcGain_t
----------------------

**typedef struct cnispDrcGain**

**{**
  
  **cnU32_t u32DrcGain;**

  **cnU32_t u32DrcGainOffset;**

**} cnispDrcGain_t;**

动态范围压缩增益属性。

**成员说明**

* u32DrcGain

  动态范围压缩数字增益。取值范围为[0x0,0xfff]。

* u32DrcGainOffset

  动态范围压缩数字增益偏移量。取值范围为[0x0,0xfffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDrcAuto_t:

struct cnispDrcAuto_t
----------------------

**typedef struct cnispDrcAuto**

**{**
  
  **cnU32_t u32DarkPrc;**

  **cnU32_t u32BrightPrc;**

  **cnU32_t u32MinDk;**

  **cnU32_t u32MaxDk;**

  **cnU32_t u32PdCutMin;**

  **cnU32_t u32PdCutMax;**

  **cnU32_t u32DarkContrastMin;**

  **cnU32_t u32DarkContrastMax;**

  **cnU32_t u32MinStr;**

  **cnU32_t u32MaxStr;**

  **cnU32_t u32DarkPrcGainTarget;**

  **cnU32_t u32ContrastMin;**

  **cnU32_t u32ContrastMax;**

  **cnU32_t u32MaxIridixGain;**

  **cnU8_t u8AvgCoef;**

  **cnU8_t u8StrengthMaximum;**

  **cnU16_t u16StrengthMinimum;**

  **cnU32_t u32EvLimFullStr;**

  **cnU32_t u32EvLimNoStr[2];**

**} cnispDrcAuto_t;**

动态范围压缩自动参数属性。

**成员说明**

* u32DarkPrc

  像素暗区百分比。取值范围为[0x0,0x64]。

* u32BrightPrc

  像素亮区百分比。取值范围为[0x0,0x64]。

* u32MinDk

  亮度增强（dark_enh）最小值。取值范围为[0x0,0xffff]。

* u32MaxDk

  亮度增强（dark_enh）最大暗度值。取值范围为[0x0,0xffff]。

* u32PdCutMin

  pD_cut 最小值。取值范围为[0x0,0xff]。

* u32PdCutMax

  pD_cut 最大值。取值范围为[0x0,0xff]。

* u32DarkContrastMin

  暗区对比度最小值。取值范围为[0x0,0xffff]。

* u32DarkContrastMax

  暗区对比度最大值。取值范围为[0x0,0xffff]。

* u32MinStr

  强度最小值。取值范围为[0x0,0x64]。

* u32MaxStr

  强度最大值。取值范围为[0x0,0x64]。

* u32DarkPrcGainTarget

  暗区目标亮度的增益。取值范围为[0x0,0x64]。

* u32ContrastMin

  对比度最小值。取值范围为[0x0,0xffff]。

* u32ContrastMax

  对比度最大值。取值范围为[0x0,0xffff]。

* u32MaxIridixGain

  算法增益最大值。取值范围为[0x0,0xff]。

* u8AvgCoef

  时域滤波。取值范围为[0x0,0xff]。

* u8StrengthMaximum

  强度最大值。取值范围为[0x0,0xff]。

* u16StrengthMinimum

  强度最小值。取值范围为[0x0,0xff]。

* u32EvLimFullStr

  根据 EV 表,高于此值,算法强度设置为最大强度。取值范围为[0x0,0xffffffff]。

* u32EvLimNoStr[2]

  EV 值小于 [0]，强度设置为 max_str，EV 值小于[1]，亮度增强（dark_enh） 设为 min Min_dk。取值范围为[0x0,0xffffffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDrc_t:

struct cnispDrc_t
------------------

**typedef struct cnispDrc**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU8_t u8drcEnable;**

  **cnU32_t u32VarianceSpace;**

  **cnU32_t u32VarianceIntensity;**

  **cnU32_t u32SlopeMax;**

  **cnU32_t u32SlopeMin;**

  **cnU32_t u32BlackLevel;**

  **cnU32_t u32WhiteLevel;**

  **cnU32_t u32CollectionCorrection;**

  **cnU32_t u32FwdPerceptControl;**

  **cnU32_t u32RevPerceptControl;**

  **cnU32_t u32StrengthInroi;**

  **cnU32_t u32StrengthOutroi;**

  **cnU32_t u32RoiHorStart;**

  **cnU32_t u32RoiHorEnd;**

  **cnU32_t u32RoiVerStart;**

  **cnU32_t u32RoiVerEnd;**

  **cnU32_t u32FiterMux;**

  **cnU32_t u32Svariance;**

  **cnU32_t u32BrightPr;**

  **cnU32_t u32Contrast;**

  **cnU32_t u32DarkEnh;**

  **cnU32_t u32FwdAlpha;**

  **cnU32_t u32RevAlpha;**

  **cnU32_t u32ContextNo;**

  :ref:`cnispDrcGain_t<cnispDrcGain_t>` **stDrcGain;**

  :ref:`cnispDrcAuto_t<cnispDrcAuto_t>` **stAuto;**

  **cnU32_t u32AsymmetryLUT[65];**

**} cnispDrc_t;**

动态范围压缩属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u8drcEnable

  使能动态范围压缩功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32VarianceSpace

  方差空间，表示算法灵敏度。取值范围为[0x0,0xf]。

* u32VarianceIntensity

  方差强度，表示算法灵敏度。取值范围为[0x0,0xf]。

* u32SlopeMax

  软算法的最大斜率。取值范围为[0x0,0xff]。

* u32SlopeMin

  软算法的最小斜率。取值范围为[0x0,0xff]。

* u32BlackLevel

  黑电平阈值，只处理像素强度在这之上的像素。取值范围为[0x0,0xfffff]。

* u32WhiteLevel

  白电平阈值，只处理像素强度在这之下的像素。取值范围为[0x0,0xfffff]。

* u32CollectionCorrection

  数据收集校正。取值范围为[0x0,0xfff]。

* u32FwdPerceptControl

  正向 Gamma 选择模式。取值范围为[0x0,0x3]。

* u32RevPerceptControl

  反向 Gamma 选择模式。取值范围为[0x0,0x3]。

* u32StrengthInroi

  输入感兴趣区域强度。取值范围为[0x0,0x3ff]。

* u32StrengthOutroi

  输出感兴趣区域强度。取值范围为[0x0,0x3ff]。

* u32RoiHorStart

  感兴趣区域水平起始位置。取值范围为[0x0,0xffff]。

* u32RoiHorEnd

  感兴趣区域水平结束位置。取值范围为[0x0,0xffff]。

* u32RoiVerStart

  感兴趣区域垂直起始位置。取值范围为[0x0,0xffff]。

* u32RoiVerEnd

  感兴趣区域垂直结束位置。取值范围为[0x0,0xffff]。

* u32FiterMux

  版本选择位。取值范围为[0x0,0x1]，0x0为版本7，0x1为版本8。

* u32Svariance

  动态范围方差，控制对比度。取值范围为[0x0,0xf]。

* u32BrightPr

  控制亮区强度。取值范围为[0x0,0xff]。

* u32Contrast

  控制中部区间的对比度。取值范围为[0x0,0xff]。

* u32DarkEnh

  暗区增强参数。取值范围为[0x0,0xffff]。

* u32FwdAlpha

  正向 alpha值。取值范围为[0x0,0x3ffff]。

* u32RevAlpha

  反向 alpha值。取值范围为[0x0,0x3ffff]。

* u32ContextNo

  输入帧的context ID。取值范围为[0x0,0x3]。

* stDrcGain

  动态范围压缩增益。取值范围详见 :ref:`cnispDrcGain_t<cnispDrcGain_t>` 。

* stAuto

  动态范围压缩自动参数。取值范围详见 :ref:`cnispDrcAuto_t<cnispDrcAuto_t>` 。

* u32AsymmetryLUT[65]

  非对称曲线查找表。取值范围为[0x0,0xfffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDemosaicManual_t:

struct cnispDemosaicManual_t
-----------------------------

**typedef struct cnispDemosaicManual**

**{**
  
  **cnU16_t u16VhSlope;**

  **cnU16_t u16AaSlope;**

  **cnU16_t u16VaSlope;**

  **cnU16_t u16UuSlope;**

  **cnU16_t u16VhThresh;**

  **cnU16_t u16AaThresh;**

  **cnU16_t u16VaThresh;**

  **cnU16_t u16UuThresh;**

  **cnU16_t u16VhOffset;**

  **cnU16_t u16AaOffset;**

  **cnU16_t u16VaOffset;**

  **cnU16_t u16UuOffset;**

**} cnispDemosaicManual_t;**

去马赛克手动参数属性。

**成员说明**

* u16VhSlope

  VH（水平/垂直）梯度检测的斜率。取值范围为[0x0,0xff]。

* u16AaSlope

  AA（45 度/135 度）梯度检测的斜率。取值范围为[0x0,0xff]。

* u16VaSlope

  VA（水平/垂直/45 度/135 度）梯度检测的斜率。取值范围为[0x0,0xff]。

* u16UuSlope

  UU（无方向性）梯度检测的斜率。取值范围为[0x0,0xff]。

* u16VhThresh

  VH阈值。取值范围为[0x0,0xfff]。

* u16AaThresh

  AA阈值。取值范围为[0x0,0xfff]。

* u16VaThresh

  VA阈值。取值范围为[0x0,0xfff]。

* u16UuThresh

  UU阈值。取值范围为[0x0,0xfff]。

* u16VhOffset

  VH偏移量。取值范围为[0x0,0xfff]。

* u16AaOffset

  AA偏移量。取值范围为[0x0,0xfff]。

* u16VaOffset

  VA偏移量。取值范围为[0x0,0xfff]。

* u16UuOffset

  UU偏移量。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDemosaicAuto_t:

struct cnispDemosaicAuto_t
---------------------------

**typedef struct cnispDemosaicAuto**

**{**
  
  **cnU16_t u16VhSlope[16][2];**

  **cnU16_t u16AaSlope[16][2];**

  **cnU16_t u16VaSlope[16][2];**

  **cnU16_t u16UuSlope[16][2];**

  **cnU16_t u16VhThresh[16][2];**

  **cnU16_t u16AaThresh[16][2];**

  **cnU16_t u16VaThresh[16][2];**

  **cnU16_t u16UuThresh[16][2];**

  **cnU16_t u16VhOffset[16][2];**

  **cnU16_t u16AaOffset[16][2];**

  **cnU16_t u16VaOffset[16][2];**

  **cnU16_t u16UuOffset[16][2];**

**} cnispDemosaicAuto_t;**

去马赛克自动参数属性。

**成员说明**

* u16VhSlope[16][2]

  VH增益-斜率表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为斜率，可取值为[0x0,0xff]。

* u16AaSlope[16][2]

  AA增益-斜率表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为斜率，可取值为[0x0,0xff]。

* u16VaSlope[16][2]

  VA增益-斜率表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为斜率，可取值为[0x0,0xff]。

* u16UuSlope[16][2]

  UU增益-斜率表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为斜率，可取值为[0x0,0xff]。

* u16VhThresh[16][2]

  VH增益-阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值，可取值为[0x0,0xff]。

* u16AaThresh[16][2]

  AA增益-阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值，可取值为[0x0,0xff]。

* u16VaThresh[16][2]

  VA增益-阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值，可取值为[0x0,0xff]。

* u16UuThresh[16][2]

  UU增益-阈值表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为阈值，可取值为[0x0,0xff]。

* u16VhOffset[16][2]

  VH增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xff]。

* u16AaOffset[16][2]

  AA增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xff]。

* u16VaOffset[16][2]

  VA增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xff]。

* u16UuOffset[16][2]

  UU增益-偏移量表。取值范围为第一列为增益，可取值为[0x0,0xffff]，第二列为偏移量，可取值为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDemosaic_t:

struct cnispDemosaic_t
-----------------------

**typedef struct cnispDemosaic**

**{**
  
:ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

:ref:`ispDemosaicConfigE<ispDemosaicConfigE>` **enDmscCfg;**

**cnU32_t u32SatSlope;**

**cnU32_t u32LgDetSlope;**

**cnU32_t u32GreyDetSlope;**

**cnU32_t u32AcSlope;**

**cnU32_t u32UuShSlope;**

**cnU32_t u32SatThresh;**

**cnU32_t u32LumThresh;**

**cnU32_t u32LgDetThresh;**

**cnU32_t u32GreyDetThresh;**

**cnU32_t u32AcThresh;**

**cnU32_t u32UuShThresh;**

**cnU32_t u32SatOffset;**

**cnU32_t u32AcOffset;**

**cnU32_t u32UuShOffset;**

**cnU32_t u32SharpAltD;**

**cnU32_t u32SharpAltUd;**

**cnU32_t u32MinDStrength;**

**cnU32_t u32MinUdStrength;**

**cnU32_t u32MaxDStrength;**

**cnU32_t u32MaxUdStrength;**

**cnU32_t u32SharpAltLd;**

**cnU32_t u32SharpAltLdu;**

**cnU32_t u32SharpAltLu;**

**cnU32_t u32SadAmp;**

**cnU32_t u32NpOffset;**

**cnU32_t u32FcSlope;**

**cnU32_t u32FcAliasSlope;**

**cnU32_t u32FcAliasThresh;**

**cnU32_t u32SharpenAlgSelect;**

**cnU32_t u32LumaThreshLowD;**

**cnU32_t u32LumaOffsetLowD;**

**cnU32_t u32LumaSlopeLowD;**

**cnU32_t u32LumaThreshHighD;**

**cnU32_t u32LumaSlopeHighD;**

**cnU32_t u32LumaThreshLowUd;**

**cnU32_t u32LumaOffsetLowUd;**

**cnU32_t u32LumaSlopeLowUd;**

**cnU32_t u32LumaThreshHighUd;**

**cnU32_t u32LumaSlopeHighUd;**

:ref:`cnispDemosaicManual_t<cnispDemosaicManual_t>` **stManual;**

:ref:`cnispDemosaicAuto_t<cnispDemosaicAuto_t>` **stAuto;**

**cnU8_t u8WeightLut[128];**

**cnU8_t u8NpOff;**

**cnU8_t u8NpOffReflect;**

**} cnispDemosaic_t;**

去马赛克属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* enDmscCfg

  去马赛克调式模式。取值范围详见 :ref:`ispDemosaicConfigE<ispDemosaicConfigE>` 。

* u32SatSlope

  饱和度斜率。取值范围为[0x0,0xff]。

* u32LgDetSlope

  低绿检测斜率。取值范围为[0x0,0xffff]。

* u32GreyDetSlope

  灰度检测斜率。取值范围为[0x0,0xffff]。

* u32AcSlope

  AC blending 斜率。取值范围为[0x0,0xff]。

* u32UuShSlope

  UU斜率。取值范围为[0x0,0xff]。

* u32SatThresh

  饱和度阈值。取值范围为[0x0,0xfff]。

* u32LumThresh

  亮度阈值。取值范围为[0x0,0xfff]。

* u32LgDetThresh

  低绿检测阈值。取值范围为[0x0,0xff]。

* u32GreyDetThresh

  灰度检测阈值。取值范围为[0x0,0xff]。

* u32AcThresh

  AC blending 阈值。取值范围为[0x0,0xfff]。

* u32UuShThresh

  UU阀值。取值范围为[0x0,0xfff]。

* u32SatOffset

  饱和度偏移量。取值范围为[0x0,0xfff]。

* u32AcOffset

  AC blending 偏移量。取值范围为[0x0,0xfff]。

* u32UuShOffset

  UU偏移量。取值范围为[0x0,0xfff]。

* u32SharpAltD

  有方向锐化检测强度。取值范围为[0x0,0xff]。

* u32SharpAltUd

  无方向锐化检测强度。取值范围为[0x0,0xff]。

* u32MinDStrength

  有方向锐化最小强度。取值范围为[0x0,0x1fff]。

* u32MinUdStrength

  无方向锐化最小强度。取值范围为[0x0,0x1fff]。

* u32MaxDStrength

  有方向锐化最大强度。取值范围为[0x0,0x1fff]。

* u32MaxUdStrength

  无方向锐化最大强度。取值范围为[0x0,0x1fff]。

* u32SharpAltLd

  高频锐化强度。取值范围为[0x0,0xff]。

* u32SharpAltLdu

  中频锐化强度。取值范围为[0x0,0xff]。

* u32SharpAltLu

  低频锐化强度。取值范围为[0x0,0xff]。

* u32SadAmp

  高中频混合值。取值范围为[0x0,0xff]。

* u32NpOffset

  噪声模型偏移量。取值范围为[0x0,0xff]。

* u32FcSlope

  去伪彩斜率，降饱和度。取值范围为[0x0,0xff]。

* u32FcAliasSlope

  去伪彩模块斜率。取值范围为[0x0,0xff]。

* u32FcAliasThresh

  去伪彩频叠阈值。取值范围为[0x0,0xff]。

* u32SharpenAlgSelect

  锐化算法选择。取值范围为[0x0,0x1]。

* u32LumaThreshLowD

  有方向亮度低档阈值，高于这个值的数值将被锐化。取值范围为[0x0,0xfff]。

* u32LumaOffsetLowD

  有方向亮度低档偏移量。取值范围为[0x0,0xff]。

* u32LumaSlopeLowD

  有方向亮度低档斜率。取值范围为[0x0,0xfffff]。

* u32LumaThreshHighD

  有方向亮度高档阈值，低于这个值的数值将被锐化。取值范围为[0x0,0xfff]。

* u32LumaSlopeHighD

  有方向亮度高档斜率。取值范围为[0x0,0xfffff]。

* u32LumaThreshLowUd

  无方向亮度低档阈值，高于这个值的数值将被锐化。取值范围为[0x0,0xfff]。

* u32LumaOffsetLowUd

  无方向亮度低档偏移量。取值范围为[0x0,0xff]。

* u32LumaSlopeLowUd

  无方向亮度低档斜率。取值范围为[0x0,0xfffff]。

* u32LumaThreshHighUd

  无方向亮度高档阈值，低于这个值的数值将被锐化。取值范围为[0x0,0xfff]。

* u32LumaSlopeHighUd

  无方向亮度高档斜率。取值范围为[0x0,0xfffff]。

* stManual

  手动去马赛克参数。取值范围为详见：:ref:`cnispDemosaicManual_t<cnispDemosaicManual_t>` 。

* stAuto

  自动去马赛克参数。取值范围为详见：:ref:`cnispDemosaicAuto_t<cnispDemosaicAuto_t>` 。

* u8WeightLut[128]

  马赛克噪声配表。取值范围为[0x0,0xff]。

* u8NpOff

  噪声模型黑电平偏移量。取值范围为[0x0,0x7f]。

* u8NpOffReflect

  噪声模型反射选择项。取值范围为[0x0,0x1]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispPf_t:

struct cnispPf_t
-----------------

**typedef struct cnispPf**

**{**
  
  **cnU8_t u8DebugSel;**

  **cnU16_t u16SaturationStrength;**

  **cnU16_t u16HslSlope;**

  **cnU16_t u16HslThresh;**

  **cnU16_t u16HslOffset;**

  **cnU16_t u16PurpleStrength;**

  **cnU8_t u8UseColorCorrectedRgb;**

  **cnU16_t u16CcmCoeffRr;**

  **cnU16_t u16CcmCoeffRg;**

  **cnU16_t u16CcmCoeffRb;**

  **cnU16_t u16CcmCoeffGr;**

  **cnU16_t u16CcmCoeffGg;**

  **cnU16_t u16CcmCoeffGb;**

  **cnU16_t u16CcmCoeffBr;**

  **cnU16_t u16CcmCoeffBg;**

  **cnU16_t u16CcmCoeffBb;**

  **cnU16_t u16HueStrength;**

  **cnU16_t u16HueLowSlope;**

  **cnU16_t u16HueLowThresh;**

  **cnU16_t u16HueLowOffset;**

  **cnU16_t u16HueHighSlope;**

  **cnU16_t u16HueHighThresh;**

  **cnU16_t u16HueHighOffset;**

  **cnU16_t u16SatStrength;**

  **cnU16_t u16SatLowSlope;**

  **cnU16_t u16SatLowThresh;**

  **cnU16_t u16SatLowOffset;**

  **cnU16_t u16SatHighSlope;**

  **cnU16_t u16SatHighThresh;**

  **cnU16_t u16SatHighOffset;**

  **cnU16_t u16LumaStrength;**

  **cnU16_t u16Luma1LowSlope;**

  **cnU16_t u16Luma1LowThresh;**

  **cnU16_t u16Luma1LowOffset;**

  **cnU16_t u16Luma1HighSlope;**

  **cnU16_t u16Luma1HighThresh;**

  **cnU16_t u16Luma1HighOffset;**

  **cnU16_t u16Luma2LowSlope;**

  **cnU16_t u16Luma2LowThresh;**

  **cnU16_t u16Luma2LowOffset;**

  **cnU16_t u16Luma2HighSlope;**

  **cnU16_t u16Luma2HighThresh;**

  **cnU16_t u16Luma2HighOffset;**

  **cnU16_t u16SadSlope;**

  **cnU16_t u16SadThresh;**

  **cnU16_t u16SadOffset;**

  **cnU16_t u16OffCenterMult;**

  **cnU16_t u16CenterX;**

  **cnU16_t u16CenterY;**

  **cnU8_t u8Lut[33];**

**} cnispPf_t;**

去紫边属性。

**成员说明**

* u8DebugSel

  调试选择功能。取值范围为[0x0,0x6]。

* u16SaturationStrength

  最终的饱和度强度。取值范围为[0x0,0xff]。

* u16HslSlope

  HSL（Hue, Saturation, Lightness）色彩模式掩码斜率。取值范围为[0x0,0xfff]。

* u16HslThresh

  HSL 色彩模式掩码阈值。取值范围为[0x0,0xfff]。

* u16HslOffset

  HSL 色彩模式掩码偏移量。取值范围为[0x0,0xfff]。

* u16PurpleStrength

  紫边强度。取值范围为[0x0,0xfff]。

* u8UseColorCorrectedRgb

  是否使用下面的 CCM 掩码表。取值范围为[0x0,0x1]，0x0：不使用，0x1：使用。

* u16CcmCoeffRr

  CCM red-red系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffRg

  CCM red-green系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffRb

  CCM red-blue系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffGr

  CCM green-red系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffGg

  CCM green-green系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffGb

  CCM green-blue系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffBr

  CCM blue-red系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffBg

  CCM blue-green系数。取值范围为[0x0,0xffff]。

* u16CcmCoeffBb

  CCM blue-blue系数。取值范围为[0x0,0xffff]。

* u16HueStrength

  色调调节掩码强度。取值范围为[0x0,0xfff]。

* u16HueLowSlope

  色度调节掩码低档斜率。取值范围为[0x0,0xfff]。

* u16HueLowThresh

  色度调节掩码低档阈值。取值范围为[0x0,0xfff]。

* u16HueLowOffset

  色度调节掩码低档偏移量。取值范围为[0x0,0xfff]。

* u16HueHighSlope

  色度调节掩码高档斜率。取值范围为[0x0,0xfff]。

* u16HueHighThresh

  色度调节掩码高档阈值。取值范围为[0x0,0xfff]。

* u16HueHighOffset

  色度调节掩码高档偏移量。取值范围为[0x0,0xfff]。

* u16SatStrength

  饱和度调节掩码强度。取值范围为[0x0,0xfff]。

* u16SatLowSlope

  饱和度调节掩码低档斜率。取值范围为[0x0,0xfff]。

* u16SatLowThresh

  饱和度调节掩码低档阈值。取值范围为[0x0,0xfff]。

* u16SatLowOffset

  饱和度调节掩码低档偏移量。取值范围为[0x0,0xfff]。

* u16SatHighSlope

  饱和度调节掩码高档斜率。取值范围为[0x0,0xfff]。

* u16SatHighThresh

  饱和度调节掩码高档阈值。取值范围为[0x0,0xfff]。

* u16SatHighOffset

  饱和度调节掩码高档偏移量。取值范围为[0x0,0xfff]。

* u16LumaStrength

  亮度调节掩码强度。取值范围为[0x0,0xfff]。

* u16Luma1LowSlope

  亮度调节1掩码低档斜率。取值范围为[0x0,0xfff]。

* u16Luma1LowThresh

  亮度调节1掩码低档阈值。取值范围为[0x0,0xfff]。

* u16Luma1LowOffset

  亮度调节1掩码低档偏移量。取值范围为[0x0,0xfff]。

* u16Luma1HighSlope

  亮度调节1掩码高档斜率。取值范围为[0x0,0xfff]。

* u16Luma1HighThresh

  亮度调节1掩码高档阈值。取值范围为[0x0,0xfff]。

* u16Luma1HighOffset

  亮度调节1掩码高档偏移量。取值范围为[0x0,0xfff]。

* u16Luma2LowSlope

  亮度调节2掩码低档斜率。取值范围为[0x0,0xfff]。

* u16Luma2LowThresh

  亮度调节2掩码低档阈值。取值范围为[0x0,0xfff]。

* u16Luma2LowOffset

  亮度调节2掩码低档偏移量。取值范围为[0x0,0xfff]。

* u16Luma2HighSlope

  亮度调节2掩码高档斜率。取值范围为[0x0,0xfff]。

* u16Luma2HighThresh

  亮度调节2掩码高档阈值。取值范围为[0x0,0xfff]。

* u16Luma2HighOffset

  亮度调节2掩码高档偏移量。取值范围为[0x0,0xfff]。

* u16SadSlope

  Sad 掩码斜率。取值范围为[0x0,0xfff]。

* u16SadThresh

  Sad 掩码阈值。取值范围为[0x0,0xfff]。

* u16SadOffset

  Sad 掩码偏移量。取值范围为[0x0,0xfff]。

* u16OffCenterMult

  Radial shading 掩码。取值范围为[0x0,0xffff]。

* u16CenterX

  横轴中心坐标。取值范围为[0x0,0xffff]。

* u16CenterY

  纵轴中心坐标。取值范围为[0x0,0xffff]。

* u8Lut[33]

  同轴圆阴影掩码查找表。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCcmManual_t:

struct cnispCcmManual_t
------------------------

**typedef struct cnispCcmManual**

**{**
  
  **cnU8_t u8CcmEnable;**

  **cnU32_t u32CoefftRIr;**

  **cnU32_t u32CoefftGIr;**

  **cnU32_t u32CoefftBIr;**

  **cnU32_t u32CoefftWbR;**

  **cnU32_t u32CoefftWbG;**

  **cnU32_t u32CoefftWbB;**

  **cnU32_t u32CoefftWbIr;**

  **cnU32_t u32CoefftFogOffsetR;**

  **cnU32_t u32CoefftFogOffsetG;**

  **cnU32_t u32CoefftFogOffsetB;**

  **cnU32_t u32CoefftFogOffsetIr;**

  **cnU16_t u16Matrix[3*3];**

**} cnispCcmManual_t;**

手动颜色校正矩阵属性。

**成员说明**

* u8CcmEnable

  使能颜色校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32CoefftRIr

  白平衡 red-IR 通道系数。取值范围为[0x0,0x1fff]。

* u32CoefftGIr

  白平衡 green-IR 通道系数。取值范围为[0x0,0x1fff]。

* u32CoefftBIr

  白平衡 blue-IR 通道系数。取值范围为[0x0,0x1fff]。

* u32CoefftWbR

  白平衡 red 通道系数。取值范围为[0x0,0xfff]。

* u32CoefftWbG

  白平衡 green 通道系数。取值范围为[0x0,0xfff]。

* u32CoefftWbB

  白平衡 blue 通道系数。取值范围为[0x0,0xfff]。

* u32CoefftWbIr

  白平衡 IR 通道系数。取值范围为[0x0,0xfff]。

* u32CoefftFogOffsetR

  去雾 red 通道偏移量。取值范围为[0x0,0xfff]。

* u32CoefftFogOffsetG

  去雾 green 通道偏移量。取值范围为[0x0,0xfff]。

* u32CoefftFogOffsetB

  去雾 blue 通道偏移量。取值范围为[0x0,0xfff]。

* u32CoefftFogOffsetIr

  去雾 IR 通道偏移量。取值范围为[0x0,0xfff]。

* u16Matrix[3*3]

  3×3矩阵系数值。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCcmAuto_t:

struct cnispCcmAuto_t
----------------------

**typedef struct cnispCcmAuto**

**{**
  
  **cnU16_t u16MatrixHigh[3*3];**

  **cnU16_t u16MatrixMed[3*3];**

  **cnU16_t u16MatrixLow[3*3];**

**} cnispCcmAuto_t;**

自动颜色校正矩阵属性。

**成员说明**

* u16MatrixHigh[3*3]

  高色温矩阵参数。取值范围为[0x0,0xffff]。

* u16MatrixMed[3*3]

  中色温矩阵参数。取值范围为[0x0,0xffff]。

* u16MatrixLow[3*3]

  低色温矩阵参数。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCcm_t:

struct cnispCcm_t
------------------

**typedef struct cnispCcm**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispCcmManual_t<cnispCcmManual_t>` **stManual;**

  :ref:`cnispCcmAuto_t<cnispCcmAuto_t>` **stAuto;**

**} cnispCcm_t;**

颜色校正矩阵属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stManual

  颜色校正矩阵手动参数。取值范围详见 :ref:`cnispCcmManual_t<cnispCcmManual_t>` 。

* stAuto

  颜色校正矩阵自动参数。取值范围详见 :ref:`cnispCcmAuto_t<cnispCcmAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispStaturationManual_t:

struct cnispStaturationManual_t
--------------------------------

**typedef struct cnispStaturationManual**

**{**
  
  **cnU32_t u32SaturationStrength;**

**} cnispStaturationManual_t;**

手动饱和度属性。

**成员说明**

* u32SaturationStrength

  手动饱和度强度值。取值范围为[0x0, 0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispStaturationAuto_t:

struct cnispStaturationAuto_t
------------------------------

**typedef struct cnispStaturationAuto**

**{**
  
  **cnU16_t u16SaturationStrength[16][2];**

**} cnispStaturationAuto_t;**

自动颜色饱和度属性。

**成员说明**

* u16SaturationStrength[16][2]

  自动饱和度增益-强度值表。取值范围为第一列为自动饱和度增益，可取值为 [0x0,0xffff]，第二列为强度值，可取值为 [0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispStaturation_t:

struct cnispStaturation_t
--------------------------

**typedef struct cnispStaturation**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispStaturationManual_t<cnispStaturationManual_t>` **stManual;**

  :ref:`cnispStaturationAuto_t<cnispStaturationAuto_t>` **stAuto;**

**} cnispStaturation_t;**

颜色饱和度属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stManual

  颜色饱和度手动参数。取值范围详见 :ref:`cnispStaturationManual_t<cnispStaturationManual_t>` 。

* stAuto

  颜色饱和度自动参数。取值范围详见 :ref:`cnispStaturationAuto_t<cnispStaturationAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAuto_t:

struct cnispAuto_t
-------------------

**typedef struct cnispAuto**

**{**
  
  **cnU16_t u16Delta12Slope[16][2];**

**} cnispAuto_t;**

色度降噪自动参数属性。

**成员说明**

* u16Delta12Slope[16][2]

  Delta斜率。取值范围为[0x0,0xffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCnr_t:

struct cnispCnr_t
------------------

**typedef struct cnispCnr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU8_t u8SquareRootEnable;**

  **cnU8_t u8CnrEnable;**

  **cnU8_t u8Mode;**

  **cnU8_t u8EffectiveKernel;**

  **cnU32_t u32UCenter;**

  **cnU32_t u32VCenter;**

  **cnU32_t u32DebugReg;**

  **cnU32_t u32GlobalOffset;**

  **cnU32_t u32GlobalSlope;**

  **cnU32_t u32UvSeg1Slope;**

  **cnU32_t u32UvSeg1Threshold;**

  **cnU32_t u32UvSeg1Offset;**

  **cnU32_t u32Umean1Slope;**

  **cnU32_t u32Umean1Threshold;**

  **cnU32_t u32Umean1Offset;**

  **cnU32_t u32Umean2Slope;**

  **cnU32_t u32Umean2Threshold;**

  **cnU32_t u32Umean2Offset;**

  **cnU32_t u32Vmean1Slope;**

  **cnU32_t u32Vmean1Threshold;**

  **cnU32_t u32Vmean1Offset;**

  **cnU32_t u32Vmean2Slope;**

  **cnU32_t u32Vmean2Threshold;**

  **cnU32_t u32Vmean2Offset;**

  **cnU32_t u32UvVar1Slope;**

  **cnU32_t u32UvVar1Threshold;**

  **cnU32_t u32UvVar1Offset;**

  **cnU32_t u32UvVar2Slope;**

  **cnU32_t u32UvVar2Threshold;**

  **cnU32_t u32UvVar2Offset;**

  **cnU32_t u32UvVar1Scale;**

  **cnU32_t u32UvVar2Scale;**

  **cnU32_t u32UvDelta1Slope;**

  **cnU32_t u32UvDelta1Threshold;**

  **cnU32_t u32UvDelta1Offset;**

  **cnU32_t u32UvDelta2Slope;**

  **cnU32_t u32UvDelta2Threshold;**

  **cnU32_t u32UvDelta2Offset;**

  :ref:`cnispAuto_t<cnispAuto_t>` **stAuto;**

**} cnispCnr_t;**

色度降噪属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u8SquareRootEnable

  使能色度降噪前后平方根运算功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8CnrEnable

  使能色度降噪功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8Mode

  色度降噪模式选择。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8EffectiveKernel

  有效的滤波内核。取值范围为[0x0,0x7f]。

* u32UCenter

  u分量中心坐标。取值范围为[0x0,0xfff]。

* u32VCenter

  v分量中心坐标。取值范围为[0x0,0xfff]。

* u32DebugReg

  调试寄存器。取值范围为[0x0,0x1]。

* u32GlobalOffset

  全局偏移量。取值范围为[0x0,0xfff]。

* u32GlobalSlope

  全局斜率。取值范围为[0x0,0xffff]。

* u32UvSeg1Slope

  uv分量西格玛标准差1斜率。取值范围为[0x0,0xffff]。

* u32UvSeg1Threshold

  uv分量西格玛标准差1阈值。取值范围为[0x0,0xfff]。

* u32UvSeg1Offset

  uv分量西格玛标准差1偏移量。取值范围为[0x0,0xfff]。

* u32Umean1Slope

  u分量均值1斜率。取值范围为[0x0,0xffff]。

* u32Umean1Threshold

  u分量均值1阈值。取值范围为[0x0,0xfff]。

* u32Umean1Offset

  u分量均值1偏移量。取值范围为[0x0,0xfff]。

* u32Umean2Slope

  u分量均值2斜率。取值范围为[0x0,0xffff]。

* u32Umean2Threshold

  u分量均值2阈值。取值范围为[0x0,0xfff]。

* u32Umean2Offset

  u分量均值2偏移量。取值范围为[0x0,0xfff]。

* u32Vmean1Slope

  v分量均值1斜率。取值范围为[0x0,0xffff]。

* u32Vmean1Threshold

  v分量均值1阈值。取值范围为[0x0,0xfff]。

* u32Vmean1Offset

  v分量均值1偏移量。取值范围为[0x0,0xfff]。

* u32Vmean2Slope

  u分量均值2斜率。取值范围为[0x0,0xffff]。

* u32Vmean2Threshold

  u分量均值2阈值。取值范围为[0x0,0xfff]。

* u32Vmean2Offset

  u分量均值2偏移量。取值范围为[0x0,0xfff]。

* u32UvVar1Slope

  uv分量方差1斜率。取值范围为[0x0,0xffff]。

* u32UvVar1Threshold

  uv分量方差1阈值。取值范围为[0x0,0xfff]。

* u32UvVar1Offset

  uv分量方差1偏移量。取值范围为[0x0,0xfff]。

* u32UvVar2Slope

  uv分量方差2偏移量。取值范围为[0x0,0xffff]。

* u32UvVar2Threshold

  uv分量方差2阈值。取值范围为[0x0,0xfff]。

* u32UvVar2Offset

  uv分量方差2偏移量。取值范围为[0x0,0xfff]。

* u32UvVar1Scale

  uv分量方差1比例值。取值范围为[0x0,0x3f]。

* u32UvVar2Scale

  uv分量方差2比例值。取值范围为[0x0,0x3f]。

* u32UvDelta1Slope

  uv分量Delta增量1斜率。取值范围为[0x0,0xffff]。

* u32UvDelta1Threshold

  uv分量Delta增量1阈值。取值范围为[0x0,0xfff]。

* u32UvDelta1Offset

  uv分量Delta增量1偏移量。取值范围为[0x0,0xfff]。

* u32UvDelta2Slope

  uv分量Delta增量2斜率。取值范围为[0x0,0xffff]。

* u32UvDelta2Threshold

  uv分量Delta增量2阈值。取值范围为[0x0,0xfff]。

* u32UvDelta2Offset

  uv分量Delta增量2偏移量。取值范围为[0x0,0xfff]。

* stAuto

  自动Delta增量参数。取值范围详见 :ref:`cnispAuto_t<cnispAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGammaManualGamma_t:

struct cnispGammaManualGamma_t
-------------------------------

**typedef struct cnispGammaManualGamma**

**{**
  
  **cnU16_t u16GammaLut[129];**

**} cnispGammaManualGamma_t;**

Gamma手动查找表属性。

**成员说明**

* u16GammaLut[129]

  Gamma查找表。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGammaAutoGamma_t:

struct cnispGammaAutoGamma_t
-----------------------------

**typedef struct cnispGammaAutoGamma**

**{**
  
  **cnU32_t u32GammanThreshold[2];**

  **cnU16_t u16GammaEv1[129];**

  **cnU16_t u16GammaEv2[129];**

**} cnispGammaAutoGamma_t;**

Gamma自动查找表属性。

**成员说明**

* u32GammanThreshold[2]

  Gamma切换的阈值。取值范围为[0x0,0xffffffff]。

* u16GammaEv1[129]

  Gamma ev1映射表。取值范围为[0x0,0xfff]。

* u16GammaEv2[129]

  Gamma ev2映射表。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispAutoLevelAuto_t:

struct cnispAutoLevelAuto_t
----------------------------

**typedef struct cnispAutoLevel**

**{**
  
  **cnU32_t u32EnableAutoLevel;**

  **cnU32_t u32BlackPercentage;**

  **cnU32_t u32WhitePercentage;**

  **cnU32_t u32AutoBlackMinClip;**

  **cnU32_t u32AutoBlackMaxClip;**

  **cnU32_t u32HighlightTarget;**

  **cnU32_t u32AvgCoeff;**

**} cnispAutoLevelAuto_t;**

Gamma 自动等级自动属性。

**成员说明**

* u32EnableAutoLevel

  使能自动调整功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u32BlackPercentage

  黑色百分比。取值范围为[0x0,0x64]。

* u32WhitePercentage

  白色百分比。取值范围为[0x0,0x64]。

* u32AutoBlackMinClip

  黑色百分比自动裁剪最小值。取值范围为[0x0,0x64]。

* u32AutoBlackMaxClip

  黑色百分比自动裁剪最大值。取值范围为[0x0,0x64]。

* u32HighlightTarget

  高亮目标值。取值范围为[0x0,0x64]。

* u32AvgCoeff

  均衡系数。取值范围为[0x0,0xff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGammaGainOffset_t:

struct cnispGammaGainOffset_t
------------------------------

**typedef struct cnispGmamaGainOffset**

**{**
  
  **cnU32_t u32GainR;**

  **cnU32_t u32GainG;**

  **cnU32_t u32GainB;**

  **cnU32_t u32OffsetR;**

  **cnU32_t u32OffsetG;**

  **cnU32_t u32OffsetB;**

**} cnispGammaGainOffset_t;**

Gamma增益和偏移量属性。

**成员说明**

* u32GainR

  R分量增益。取值范围为[0x0,0xfff]。

* u32GainG

  G分量增益。取值范围为[0x0,0xfff]。

* u32GainB

  B分量增益。取值范围为[0x0,0xfff]。

* u32OffsetR

  R分量偏移量。取值范围为[0x0,0xfff]。

* u32OffsetG

  G分量偏移量。取值范围为[0x0,0xfff]。

* u32OffsetB

  B分量偏移量。取值范围为[0x0,0xfff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGammaAutoLevelAttr_t:

struct cnispGammaAutoLevelAttr_t
---------------------------------

**typedef struct cnispGammaAutoLevelAttr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  :ref:`cnispGammaGainOffset_t<cnispGammaGainOffset_t>` **stManual;**

  :ref:`cnispGammaGainOffset_t<cnispGammaGainOffset_t>` **stAutoLevelInfo;**

**} cnispGammaAutoLevelAttr_t;**

Gamma自动等级调节属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* stManual

  自动等级模式下的手动参数。取值范围为详见 :ref:`cnispGammaGainOffset_t<cnispGammaGainOffset_t>` 。

* stAutoLevelInfo

  自动等级模式下的自动参数; 取值范围为详见 :ref:`cnispGammaGainOffset_t<cnispGammaGainOffset_t>` ，只读属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispGamma_t:

struct cnispGamma_t
--------------------

**typedef struct cnispGamma**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnU8_t u8GammaEnable;**

  :ref:`cnispGammaManualGamma_t<cnispGammaManualGamma_t>` **stManualGamma;**

  :ref:`cnispGammaAutoGamma_t<cnispGammaAutoGamma_t>` **stAutoGamma;**

  :ref:`cnispGammaAutoLevelAttr_t<cnispGammaAutoLevelAttr_t>` **stAutoLevelAttr;**

  :ref:`cnispAutoLevelAuto_t<cnispAutoLevelAuto_t>` **stAutoLevelAuto;**

**} cnispGamma_t;**

Gamma校正属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* u8GammaEnable

  使能Gamma校正功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* stManualGamma

  Gamma 手动查找表参数。取值范围为详见 :ref:`cnispGammaManualGamma_t<cnispGammaManualGamma_t>` 。

* stAutoGamma

  Gamma 自动查找表参数。取值范围为详见 :ref:`cnispGammaAutoGamma_t<cnispGammaAutoGamma_t>` 。

* stAutoLevelAttr

  Gamma 自动等级参数。取值范围为详见 :ref:`cnispGammaAutoLevelAttr_t<cnispGammaAutoLevelAttr_t>` 。

* stAutoLevelAuto

  Gamma 自动等级自动参数。取值范围为详见 :ref:`cnispAutoLevelAuto_t<cnispAutoLevelAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _ispRegAttr_t:

struct ispRegAttr_t
--------------------

**typedef struct cnispRegAttr**

**{**
  
  :ref:`ispRegTypeE<ispRegTypeE>` **eRegType;**

  **cnU32_t u32Addr;**

  **cnU32_t u32Value;**

**} ispRegAttr_t;**

寄存器属性。

**成员说明**

* eRegType

  寄存器类型。取值范围详见 :ref:`ispRegTypeE<ispRegTypeE>` 。

* u32Addr

  寄存器偏移地址。

* u32Value

  寄存器值。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnisp3DLut_t:

struct cnisp3DLut_t
--------------------

**typedef struct cnisp3DLut**

**{**
  
  **cnU32_t u32Lut[1000];**

**} cnisp3DLut_t;**

色彩校正3D查找表属性。

**成员说明**

* u32Lut[1000]
 
  3D查找表值。取值范围为[0,0xffffffff]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDefogAlgPara_t:

struct cnispDefogAlgPara_t
--------------------------

**typedef struct cnispDefogAlgPara**

**{**
  
  **cnU16_t u16Strength;**

  **cnU16_t u16AirLoc;**

  **cnU16_t u16AirLocH;**

  **cnU16_t u16AirLocV;**

**} cnispDefogAlgPara_t;**

去雾参数属性。

**成员说明**

* u16Strength

  去雾强度控制，值越大，去雾程度越高。取值范围为[0x0,0x3ff]。

* u16AirLoc

  大气光位置索引。取值范围为[0x0,0x3ff]，只读属性。

* u16AirLocH

  大气光水平位置索引。取值范围为[0x0,0x1f]。

* u16AirLocV

  大气光垂直位置索引。取值范围为[0x0,0x1f]。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDefogAlgManual_t:

typedef cnispDefogAlgManual_t
----------------------------------

**typedef cnispDefogAlgPara_t cnispDefogAlgManual_t**

去雾手动参数属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDefogAlgAuto_t:

typedef cnispDefogAlgAuto_t
-------------------------------

**typedef cnispDefogAlgPara_t cnispDefogAlgAuto_t**

去雾自动参数属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDefog_t:

struct cnispDefogAttr_t
------------------------

**typedef struct cnispDefogAttr**

**{**
  
  :ref:`ispOpTypeE<ispOpTypeE>` **enOpType;**

  **cnBool_t bEnable;**

  **cnBool_t bUserLutEnable;**

  **cnU8_t u8DefogUserLut[256];**

  **cnU8_t u8DefogDefLut[256];**

  **cnU8_t u8FogMeterWei[8][8];**

  **cnU8_t u8FogMeterMode;**

  **cnU16_t u16TmprfltIncrCoef;**

  **cnU16_t u16TmprfltDecrCoef;**

  **cnU8_t u8TmprfltIncrLut[128];**

  **cnU8_t u8TmprfltDecrLut[128];**

  :ref:`cnispDefogAlgManual_t<cnispDefogAlgManual_t>` **stManual;**

  :ref:`cnispDefogAlgAuto_t<cnispDefogAlgAuto_t>` **stAuto;**

**} cnispDefogAttr_t;**

去雾属性。

**成员说明**

* enOpType

  调节类型。取值范围详见 :ref:`ispOpTypeE<ispOpTypeE>` 。

* bEnable

  使能去雾功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* bUserLutEnable

  使能用户自定义去雾强度曲线功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8DefogUserLut[256]

  用户自定义去雾强度曲线。取值范围为[0x0,0xff]。

* u8DefogDefLut[256]

  默认去雾强度曲线。取值范围为[0x0,0xff]。

* u8FogMeterWei[8][8]

  雾测量权重值。取值范围为[0x0,0xff]。

* u8FogMeterMode

  雾测量模式。取值范围详见 :ref:`ispFogMeterModeE<ispFogMeterModeE>` 。

* u16TmprfltIncrCoef

  时域滤波递增系数，值越大，画面由暗到亮收敛速度越快。取值范围为[0x0,0x80]。

* u16TmprfltDecrCoef

  时域滤波递减系数，值越大，画面由亮到暗收敛速度越快。取值范围为[0x0,0x80]。

* u8TmprfltIncrLut[128]

  时域滤波递增系数表。

* u8TmprfltDecrLut[128]

  时域滤波递减系数表。

* stManual

  去雾手动参数。取值范围为详见 :ref:`cnispDefogAlgManual_t<cnispDefogAlgManual_t>` 。

* stAuto

  去雾自动参数。取值范围为详见 :ref:`cnispDefogAlgAuto_t<cnispDefogAlgAuto_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispLdra_t:

struct cnispLdra_t
-------------------

**typedef struct cnispLdra**

**{**
  
  **cnBool_t bLdraEnable;**

  **cnBool_t bRoiEnable;**

  **cnU16_t u16GlobalLowGamma;**

  **cnU16_t u16GlobalHighGamma;**

  **cnU16_t u16RoiLowGamma;**

  **cnU16_t u16RoiHighGamma;**

  **cnU8_t u8RoiNum;**

  **cnU16_t u16UpperLeftX[10];**

  **cnU16_t u16UpperLeftY[10];**

  **cnU16_t u16RoiWidth[10];**

  **cnU16_t u16RoiHeight[10];**

**} cnispLdra_t;**

局部数据范围调整属性。

**成员说明**

* bLdraEnable

  使能局部数据范围调整功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* bRoiEnable

  使能感兴趣区域。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u16GlobalLowGamma

  LDRA模块全局调节曲线，暗区调节控制器。

* u16GlobalHighGamma

  LDRA模块全局调节曲线，亮区调节控制器。

* u16RoiLowGamma

  LDRA模块ROI区域调节曲线，暗区调节控制器。

* u16RoiHighGamma

  LDRA模块ROI区域调节曲线，亮区调节控制器。

* u8RoiNum

  LDRA模块需要处理的ROI区域个数。

* u16UpperLeftX[10]

  LDRA模块ROI区域左上顶点的X轴坐标。

* u16UpperLeftY[10]

  LDRA模块ROI区域左上顶点的Y轴坐标。

* u16RoiWidth[10]

  LDRA模块ROI区域宽度。

* u16RoiHeight[10]

  LDRA模块ROI区域高度。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCscMatrix_t:

struct cnispCscMatrix_t
------------------------

**typedef struct cnispCscMatrix**

**{**
  
  **cnS16_t s16cscIdr[3];**

  **cnS16_t s16cscOdr[3];**

  **cnS16_t s16cscCoe[9];**

**} cnispCscMatrix_t;**

颜色空间转换矩阵属性。

**成员说明**

* s16cscIdr[3]

  输入直流分量。取值范围为[-0x400,0x400)。

* s16cscOdr[3]

  输出直流分量。取值范围为[-0x400,0x400)。

* s16cscCoe[9]

  3x3矩阵系数值。取值范围为[-0x1000,0x1000)。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCscV1_t:

struct cnispCscV1_t
--------------------

**typedef struct cnispCscV1**

**{**
  
  **cnBool_t bEnable;**

  :ref:`cnispCscMatrix_t<cnispCscMatrix_t>` **ispCscMatrix;**

**} cnispCscV1_t;**

颜色空间转换功能。

**成员说明**

* bEnable

  使能颜色空间转换功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能，只读属性。

* ispCscMatrix

  颜色空间转换矩阵属性。取值范围详见 :ref:`cnispCscMatrix_t<cnispCscMatrix_t>` 。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispCds_t:

struct cnispCds_t
------------------

**typedef struct cnispCds**

**{**
  
  **cnBool_t bEnable;**

  **cnS16_t s16CdsCoefH[8];**

  **cnS16_t s16CdsCoefV[2];**

**} cnispCds_t;**

色度降采样属性。

**成员说明**

* bEnable

  使能色度降采样功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能，只读属性。

* s16CdsCoefH[8]

  水平方向滤波参数。取值范围为[-0x200,0x200]，水平8个系数相加必须等于512。

* s16CdsCoefV[2]

  垂直方向滤波参数。取值范围为[-0x200,0x200]，垂直2个系数相加必须等于512。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispDither_t:

struct cnispDither_t
---------------------

**typedef struct cnispDither**

**{**
  
  **cnBool_t bEnable;**

  :ref:`cnispDitherMode_e<cnispDitherMode_e>` **u8mode;**

  **cnU8_t u8type;**

  **cnBool_t bSeedHw;**

  **cnU8_t u8Seed;**

**} cnispDither_t;**

抖动属性。

**成员说明**

* bEnable

  使能抖动功能。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能。

* u8mode

  抖动模式。取值范围详见 :ref:`cnispDitherMode_e<cnispDitherMode_e>` 。

* u8type

  抖动类型。取值范围为[0x0,0x2)(0x2,0x5]，0x0为2bit，0x1为4bit，0x3：6bit，0x4：7bit，0x5：8bit。

* bSeedHw

  使能硬件随机种子。取值范围为[0x0,0x1]，0x0为禁止，0x1为使能；仅在u8mode为E_ISP_DITHER_LSFR时有效。

* u8Seed

  软件随机种子。取值范围为[0x0,0xff]；仅在u8mode为E_ISP_DITHER_LSFR时有效，且bSeedHw为0时有效。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispTpg1_t:

typedef cnispTpg1_t
--------------------

**typedef** :ref:`cnispTpg_t<cnispTpg_t>` **cnispTpg1_t**

测试模式属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispTpg2_t:

typedef cnispTpg2_t
--------------------

**typedef** :ref:`cnispTpg_t<cnispTpg_t>` **cnispTpg2_t**

测试模式属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispTpg3_t:

typedef cnispTpg3_t
--------------------

**typedef** :ref:`cnispTpg_t<cnispTpg_t>` **cnispTpg3_t**

测试模式属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispTpg4_t:

typedef cnispTpg4_t
------------------------------

**typedef** :ref:`cnispTpg_t<cnispTpg_t>` **cnispTpg4_t**

测试模式属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispHistMetering_t:

typedef cnispHistMetering_t
----------------------------

**typedef** :ref:`cnispMetering_t<cnispMetering_t>` **cnispHistMetering_t**

ISP 直方图统计信息属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _cnispIhistMetering_t:

typedef cnispIhistMetering_t
-----------------------------

**typedef** :ref:`cnispMetering_t<cnispMetering_t>` **cnispIhistMetering_t**

Defog 直方图统计信息属性。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _1024:

macro M_HIST_NUMBER_1024
-----------------------------

#define M_HIST_NUMBER_1024 (1024)

定义1024bin 统计直方图数组长度。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _M_HIST_5_BIN:

macro M_HIST_5_BIN
-----------------------------

#define M_HIST_5_BIN (1089*4)

定义5bin 统计直方图数组长度。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _M_AWB_MAX_ZONE_NUMBER:

macro M_AWB_MAX_ZONE_NUMBER
-----------------------------

#define M_AWB_MAX_ZONE_NUMBER (1089)

定义自动白平衡区域的最大个数。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _CN_M_ISP_LSC_GRID_COL_EX:

macro CN_M_ISP_LSC_GRID_COL_EX
--------------------------------

#define CN_M_ISP_LSC_GRID_COL_EX (32)

定义阴影校正网格列数。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _CN_M_ISP_LSC_GRID_ROW_EX:

macro CN_M_ISP_LSC_GRID_ROW_EX
---------------------------------

#define CN_M_ISP_LSC_GRID_ROW_EX (32)

定义阴影校正网格行数。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。

.. _CN_M_ISP_LSC_GRID_POINTS_EX:

macro CN_M_ISP_LSC_GRID_POINTS_EX
------------------------------------

#define CN_M_ISP_LSC_GRID_POINTS_EX ( :ref:`CN_M_ISP_LSC_GRID_COL_EX <CN_M_ISP_LSC_GRID_COL_EX>` * 
  :ref:`CN_M_ISP_LSC_GRID_ROW_EX <CN_M_ISP_LSC_GRID_ROW_EX>` )

定义阴影校正网格个数。

**注意事项**

无。

**相关数据类型**

无。

**相关接口**

无。
