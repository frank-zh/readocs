#! /bin/bash

make clean

make html&&make latexpdf
