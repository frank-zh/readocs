错误码
########################################

.. _cnispRetCode:

cnispRetCode
++++++++++++++++++++++++++++++++++++++++

* CN_ISP_PARA_SUCCESS 0

  函数运行成功。

* CN_ISP_PARA_NULL -1

  参数值为NULL。

* CN_ISP_PARA_INVALID -2

  非法的参数。

* CN_ISP_PARA_UNSUPPORT -3

  不支持的参数。

* CN_ISP_PARA_RANGER_ERROR -4

  参数范围错误。

* CN_ISP_INVALID_PIPE -5

  非法的Pipe号。

* CN_ISP_CMD_INVALID -6

  非法的命令。

* CN_ISP_INSTANCE_INVALID -7

  非法的实例。

* CN_ISP_FIRM_ERROR -8

  Firmware运行错误。

* CN_ISP_SWAP_ERROR -9

  Swap运行错误。

* CN_ISP_STATUS_ERROR -10

  运行状态错误。


