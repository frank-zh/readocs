IEP
########################################

IEP（Image Effect Processing）模块下的 API 接口必须在调用 :ref:`cnispInit<cnispInit>` 接口之后才能调用。

.. _cnispSetSquare:

cnispSetSquare
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetSquare(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispSquare_t<cnispSquare_t>`  **\* pstSquare,**

**);**

设置平方根属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstSquare

  函数入参，指定要设置的平方根属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetSquare:

cnispGetSquare
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetSquare(**

                      **viPipe_t viPipe,**

                      :ref:`cnispSquare_t<cnispSquare_t>`  **\* pstSquare,**

**);**

获取平方根属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstSquare

  函数入参，指定要获取的平方根属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetGe:

cnispSetGe
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetGe(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispGe_t<cnispGe_t>`  **\* pstGe,**

**);**

设置绿平衡属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstGe

  函数入参，指定要设置的绿平衡属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetGe:

cnispGetGe
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetGe(**

                      **viPipe_t viPipe,**

                      :ref:`cnispGe_t<cnispGe_t>`  **\* pstGe,**

**);**

获取绿平衡属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstGe

  函数入参，指定要获取的绿平衡属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDpc:

cnispSetDpc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDpc(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDpc_t<cnispDpc_t>`  **\* pstDpc,**

**);**

设置坏点校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstPub

  函数入参，指定要设置的坏点校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDpc:

cnispGetDpc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDpc(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDpc_t<cnispDpc_t>`  **\* pstDpc,**

**);**

获取坏点校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDpc

  函数入参，指定要获取的坏点校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetBnr:

cnispSetBnr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetBnr(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispBnr_t<cnispBnr_t>`  **\* pstBnr,**

**);**

设置拜耳降噪属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBnr

  函数入参，指定要设置的拜耳降噪属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetBnr:

cnispGetBnr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetBnr(**

                      **viPipe_t viPipe,**

                      :ref:`cnispBnr_t<cnispBnr_t>`  **\* pstBnr,**

**);**

获取拜耳降噪属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBnr

  函数入参，指定要获取的拜耳降噪属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetBnrLut:

cnispSetBnrLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetBnrLut(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispBnrLut_t<cnispBnrLut_t>`  **\* pstBnrLut,**

**);**

设置拜耳降噪查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBnrLut

  函数入参，指定要设置的拜耳降噪查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetBnrLut:

cnispGetBnrLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetBnrLut(**

                      **viPipe_t viPipe,**

                      :ref:`cnispBnrLut_t<cnispBnrLut_t>`  **\* pstBnrLut,**

**);**

获取拜耳降噪查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBnrLut

  函数入参，指定要获取的拜耳降噪查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCac:

cnispSetCac
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCac(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCac_t<cnispCac_t>`  **\* pstCac,**

**);**

设置色差校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCac

  函数入参，指定要设置的色差校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCac:

cnispGetCac
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCac(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCac_t<cnispCac_t>`  **\* pstCac,**

**);**

获取色差校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCac

  函数入参，指定要获取的色差校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetBlc:

cnispSetBlc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetBlc(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispBlc_t<cnispBlc_t>`  **\* pstBlc,**

**);**

设置黑电平校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBlc

  函数入参，指定要设置的黑电平校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetBlc:

cnispGetBlc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetBlc(**

                      **viPipe_t viPipe,**

                      :ref:`cnispBlc_t<cnispBlc_t>`  **\* pstBlc,**

**);**

获取黑电平校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstBlc

  函数入参，指定要获取的黑电平校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetRadialShading:

cnispSetRadialShading
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetRadialShading(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispRadialShading_t<cnispRadialShading_t>`  **\* pstRadialShading,**

**);**

设置同轴圆阴影校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstRadialShading

  函数入参，指定要设置的同轴圆阴影校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetRadialShading:

cnispGetRadialShading
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetRadialShading(**

                      **viPipe_t viPipe,**

                      :ref:`cnispRadialShading_t<cnispRadialShading_t>`  **\* pstRadialShading,**

**);**

获取同轴圆阴影校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstRadialShading

  函数入参，指定要获取的同轴圆阴影校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetRadialShadingLut:

cnispSetRadialShadingLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetRadialShadingLut(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispRadialShadingLut_t<cnispRadialShadingLut_t>`  **\* pstRadialShadingLut,**

**);**

设置同轴圆阴影校正查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstRadialShadingLut

  函数入参，指定要设置的同轴圆阴影校正查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetRadialShadingLut:

cnispGetRadialShadingLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetRadialShadingLut(**

                      **viPipe_t viPipe,**

                      :ref:`cnispRadialShadingLut_t<cnispRadialShadingLut_t>`  **\* pstRadialShadingLut,**

**);**

获取同轴圆阴影校正查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstRadialShadingLut

  函数入参，指定要获取的同轴圆阴影校正查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetMeshShading:

cnispSetMeshShading
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetMeshShading(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispMeshShading_t<cnispMeshShading_t>`  **\* pstMeshShading,**

**);**

设置网格阴影校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstMeshShading

  函数入参，指定要设置的网格阴影校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetMeshShading:

cnispGetMeshShading
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetMeshShading(**

                      **viPipe_t viPipe,**

                      :ref:`cnispMeshShading_t<cnispMeshShading_t>`  **\* pstMeshShading,**

**);**

获取网格阴影校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstMeshShading

  函数入参，指定要获取的网格阴影校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetMeshShadingLut:

cnispSetMeshShadingLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetMeshShadingLut(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispMeshShadingLut_t<cnispMeshShadingLut_t>`  **\* pstMeshShadingLut,**

**);**

设置网格阴影校正查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstMeshShadingLut

  函数入参，指定要设置的网格阴影校正查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetMeshShadingLut:

cnispGetMeshShadingLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetMeshShadingLut(**

                      **viPipe_t viPipe,**

                      :ref:`cnispMeshShadingLut_t<cnispMeshShadingLut_t>`  **\* pstMeshShadingLut,**

**);**

获取网格阴影校正查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstMeshShadingLut

  函数入参，指定要获取的网格阴影校正查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDrc:

cnispSetDrc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDrc(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDrc_t<cnispDrc_t>`  **\* pstDrc,**

**);**

设置动态范围压缩属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDrc

  函数入参，指定要设置的动态范围压缩属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDrc:

cnispGetDrc
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDrc(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDrc_t<cnispDrc_t>`  **\* pstDrc,**

**);**

获取动态范围压缩属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDrc

  函数入参，指定要获取的动态范围压缩属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDemosaic:

cnispSetDemosaic
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDemosaic(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDemosaic_t<cnispDemosaic_t>`  **\* pstDemosaic,**

**);**

设置去马赛克属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDemosaic

  函数入参，指定要设置的去马赛克属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDemosaic:

cnispGetDemosaic
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDemosaic(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDemosaic_t<cnispDemosaic_t>`  **\* pstDemosaic,**

**);**

获取去马赛克属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDemosaic

  函数入参，指定要获取的去马赛克属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetPf:

cnispSetPf
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetPf(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispPf_t<cnispPf_t>`  **\* pstPf,**

**);**

设置去紫边属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstPf

  函数入参，指定要设置的去紫边属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetPf:

cnispGetPf
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetPf(**

                      **viPipe_t viPipe,**

                      :ref:`cnispPf_t<cnispPf_t>`  **\* pstPf,**

**);**

获取去紫边属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstPf

  函数入参，指定要获取的去紫边属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCnr:

cnispSetCnr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCnr(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCnr_t<cnispCnr_t>`  **\* pstCnr,**

**);**

设置颜色降噪属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCnr

  函数入参，指定要设置的颜色降噪属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCnr:

cnispGetCnr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCnr(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCnr_t<cnispCnr_t>`  **\* pstCnr,**

**);**

获取颜色降噪属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCnr

  函数入参，指定要获取的颜色降噪属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetGamma:

cnispSetGamma
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetGamma(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispGamma_t<cnispGamma_t>`  **\* pstGamma,**

**);**

设置Gamma校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstGamma

  函数入参，指定要设置的Gamma校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetGamma:

cnispGetGamma
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetGamma(**

                      **viPipe_t viPipe,**

                      :ref:`cnispGamma_t<cnispGamma_t>`  **\* pstGamma,**

**);**

获取Gamma校正属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstGamma

  函数入参，指定要获取的Gamma校正属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSet3DLut:

cnispSet3DLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSet3DLut(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnisp3DLut_t<cnisp3DLut_t>`  **\* pst3DLut,**

**);**

设置三维颜色调整查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pst3DLut

  函数入参，指定要设置的三维颜色调整查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGet3DLut:

cnispGet3DLut
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGet3DLut(**

                      **viPipe_t viPipe,**

                      :ref:`cnisp3DLut_t<cnisp3DLut_t>`  **\* pst3DLut,**

**);**

获取三维颜色调整查找表属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pst3DLut

  函数入参，指定要获取的三维颜色调整查找表属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDefog:

cnispSetDefog
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDefog(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDefog_t<cnispDefog_t>`  **\* pstDefog,**

**);**

设置去雾属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDefog

  函数入参，指定要设置的去雾属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDefog:

cnispGetDefog
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDefog(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDefog_t<cnispDefog_t>`  **\* pstDefog,**

**);**

获取去雾属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDefog

  函数入参，指定要获取的去雾属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetLdra:

cnispSetLdra
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetLdra(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispLdra_t<cnispLdra_t>`  **\* pstLdra,**

**);**

设置局部亮度调整属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstLdra

  函数入参，指定要设置的局部亮度调整属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetLdra:

cnispGetLdra
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetLdra(**

                      **viPipe_t viPipe,**

                      :ref:`cnispLdra_t<cnispLdra_t>`  **\* pstLdra,**

**);**

获取局部亮度调整属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstLdra

  函数入参，指定要获取的局部亮度调整属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCscV1:

cnispSetCscV1
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCscV1(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCscV1_t<cnispCscV1_t>`  **\* pstCscV1,**

**);**

设置颜色空间转换属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCscV1

  函数入参，指定要设置的颜色空间转换属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCscV1:

cnispGetCscV1
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCscV1(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCscV1_t<cnispCscV1_t>`  **\* pstCscV1,**

**);**

获取颜色空间转换属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCscV1

  函数入参，指定要获取的颜色空间转换属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCds:

cnispSetCds
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCds(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCds_t<cnispCds_t>`  **\* pstCds,**

**);**

设置颜色空间降采样属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCds

  函数入参，指定要设置的颜色空间降采样属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCds:

cnispGetCds
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCds(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCds_t<cnispCds_t>`  **\* pstCds,**

**);**

获取颜色空间降采样属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCds

  函数入参，指定要获取的颜色空间降采样属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDither:

cnispSetDither
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDither(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDither_t<cnispDither_t>`  **\* pstDither,**

**);**

设置抖动属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDither

  函数入参，指定要设置的抖动属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDither:

cnispGetDither
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDither(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDither_t<cnispDither_t>`  **\* pstDither,**

**);**

获取抖动属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDither

  函数入参，指定要获取的抖动属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetFsWdr:

cnispSetFsWdr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetFsWdr(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispFsWdr_t<cnispFsWdr_t>`  **\* pstFsWdr,**

**);**

设置宽动态范围帧融合属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstFsWdr

  函数入参，指定要设置的宽动态范围帧融合属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetFsWdr:

cnispGetFsWdr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetFsWdr(**

                      **viPipe_t viPipe,**

                      :ref:`cnispFsWdr_t<cnispFsWdr_t>`  **\* pstFsWdr,**

**);**

获取宽动态范围帧融合属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstFsWdr

  函数入参，指定要获取的宽动态范围帧融合属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetWdrNoiseProfile:

cnispSetWdrNoiseProfile
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetWdrNoiseProfile(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispWdrNoiseProfile_t<cnispWdrNoiseProfile_t>`  **\* pstWdrNoiseProfile,**

**);**

设置宽动态范围噪声特性属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWdrNoiseProfile

  函数入参，指定要设置的宽动态范围噪声特性属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetWdrNoiseProfile:

cnispGetWdrNoiseProfile
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetWdrNoiseProfile(**

                      **viPipe_t viPipe,**

                      :ref:`cnispWdrNoiseProfile_t<cnispWdrNoiseProfile_t>`  **\* pstWdrNoiseProfile,**

**);**

获取宽动态范围噪声特性属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWdrNoiseProfile

  函数入参，指定要获取的宽动态范围噪声特性属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。
