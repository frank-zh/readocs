AE
########################################

.. 自动曝光

.. AE 模块实现的功能是:根据自动测光系统获得当前图像的曝光量，再自动配置
 镜头光圈、sensor 快门及增益来获得最佳的图像质量。自动曝光的算法主要分光圈优
 先、快门优先、增益优先。光圈优先时算法会优先调整光圈到合适的位置,再分配曝
 光时间和增益,只适合 p-iris 镜头，这样能均衡噪声和景深。快门优先时算法会优先分
 配曝光时间，再分配 sensor 增益和 ISP 增益,这样拍摄的图像噪声会比较小。增益优
 先则是优先分配 sensor 增益和 ISP 增益，再分配曝光时间，适合拍摄运动物体的场
 景。当前 AE 算法也支持客户设定更灵活的曝光分配策略。

.. _cnispSetExposure:

cnispSetExposure
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetExposure(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispExposure_t<cnispExposure_t>`  **\* pstExposure,**

**);**

设置 AE 曝光属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstExposure

  函数入参，指定要设置的 AE 曝光属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetExposure:

cnispGetExposure
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetExposure(**

                      **viPipe_t viPipe,**

                      :ref:`cnispExposure_t<cnispExposure_t>`  **\* pstExposure,**

**);**

获取 AE 曝光属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstExposure

  函数出参，指定要获取的 AE 曝光属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetExposureInfo:

cnispSetExposureInfo
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetExposureInfo(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispExposureInfo_t<cnispExposureInfo_t>`  **\* pstExposureInfo,**

**);**

设置 AE 曝光信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstExposureInfo

  函数入参，指定要设置的 AE 曝光信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetExposureInfo:

cnispGetExposureInfo
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetExposureInfo(**

                      **viPipe_t viPipe,**

                      :ref:`cnispExposureInfo_t<cnispExposureInfo_t>`  **\* pstExposureInfo,**

**);**

获取 AE 曝光信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstExposureInfo

  函数出参，指定要获取的 AE 曝光信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetWdrExposure:

cnispSetWdrExposure
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetWdrExposure(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispWdrExposure_t<cnispWdrExposure_t>`  **\* pstWdrExposure,**

**);**

设置 WDR 模式下的 AE 曝光属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWdrExposure

  函数入参，指定要设置的 WDR 模式下 AE 曝光属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetWdrExposure:

cnispGetWdrExposure
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetWdrExposure(**

                      **viPipe_t viPipe,**

                      :ref:`cnispWdrExposure_t<cnispWdrExposure_t>`  **\* pstWdrExposure,**

**);**

获取 WDR 模式下的 AE 曝光属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWdrExposure

  函数出参，指定要获取的 WDR 模式下 AE 曝光属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetHistMetering:

cnispSetHistMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetHistMetering(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispHistMetering_t<cnispHistMetering_t>`  **\* pstHistMetering,**

**);**

设置直方图统计信息（ISP使用）属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstHistMetering

  函数入参，指定要设置的直方图统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetHistMetering:

cnispGetHistMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetHistMetering(**

                      **viPipe_t viPipe,**

                      :ref:`cnispHistMetering_t<cnispHistMetering_t>`  **\* pstHistMetering,**

**);**

获取直方图统计信息（ISP使用）属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstHistMetering

  函数出参，指定要获取的直方图统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetIhistMetering:

cnispSetIhistMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetIhistMetering(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispIhistMetering_t<cnispIhistMetering_t>`  **\* pstIhistMetering,**

**);**

设置直方图统计信息（Defog使用）属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstIhistMetering

  函数入参，指定要设置的直方图统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetIhistMetering:

cnispGetIhistMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetIhistMetering(**

                      **viPipe_t viPipe,**

                      :ref:`cnispIhistMetering_t<cnispIhistMetering_t>`  **\* pstIhistMetering,**

**);**

获取直方图统计信息（Defog使用）属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstIhistMetering

  函数出参，指定要获取的直方图统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。
