CCM
########################################

sensor 对光谱的响应，在 RGB 各分量上与人眼对光谱的响应通常是偏差的，通常通
过一个色彩校正矩阵校正光谱响应的交叉效应和响应强度，使前端捕获的图片与人眼
视觉在色彩上保持一致。

.. _cnispSetStaturation:

cnispSetStaturation
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetStaturation(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispStaturation_t<cnispStaturation_t>`  **\* pstStaturation,**

**);**

设置颜色饱和度属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstStaturation

  函数入参，指定要设置的颜色饱和度属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetStaturation:

cnispGetStaturation
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetStaturation(**

                      **viPipe_t viPipe,**

                      :ref:`cnispStaturation_t<cnispStaturation_t>`  **\* pstStaturation,**

**);**

获取颜色饱和度属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstStaturation

  函数入参，指定要获取的颜色饱和度属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCcm:

cnispSetCcm
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCcm(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCcm_t<cnispCcm_t>`  **\* pstCcm,**

**);**

设置颜色矩阵属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCcm

  函数入参，指定要设置的颜色矩阵属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCcm:

cnispGetCcm
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCcm(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCcm_t<cnispCcm_t>`  **\* pstCcm,**

**);**

获取颜色矩阵属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCcm

  函数入参，指定要获取的颜色矩阵属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。
