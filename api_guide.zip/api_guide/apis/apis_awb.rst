AWB
########################################

.. 自动白平衡

.. 色温随可见光的光谱成分变化而变化，在低色温光源下，白色物体偏红，在高色温光
 源下，白色物体偏蓝。人眼可根据大脑的记忆判断，识别物体的真实颜色，AWB 算法
 的功能是降低外界光源对物体真实颜色的影响，使得我们采集的颜色信息转变为在理
 想日光光源下的无偏色信息。

.. _cnispSetAwbAttr:

cnispSetAwbAttr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetAwbAttr(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispAwbAttr_t<cnispAwbAttr_t>`  **\* pstAwbAttr,**

**);**

设置白平衡属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstAwbAttr

  函数入参，指定要设置的白平衡属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetAwbAttr:

cnispGetAwbAttr
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetAwbAttr(**

                      **viPipe_t viPipe,**

                      :ref:`cnispAwbAttr_t<cnispAwbAttr_t>`  **\* pstAwbAttr,**

**);**

获取白平衡属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstAwbAttr

  函数入参，指定要获取的白平衡属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetWbInfo:

cnispSetWbInfo
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetWbInfo(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispWbInfo_t<cnispWbInfo_t>`  **\* pstWbInfo,**

**);**

设置白平衡信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWbInfo

  函数入参，指定要设置的白平衡信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetWbInfo:

cnispGetWbInfo
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetWbInfo(**

                      **viPipe_t viPipe,**

                      :ref:`cnispWbInfo_t<cnispWbInfo_t>`  **\* pstWbInfo,**

**);**

获取白平衡信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstWbInfo

  函数入参，指定要获取的白平衡信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetAwbMetering:

cnispSetAwbMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetAwbMetering(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispAwbMetering_t<cnispAwbMetering_t>`  **\* pstAwbMetering,**

**);**

设置白平衡统计信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstAwbMetering

  函数入参，指定要设置的白平衡统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetAwbMetering:

cnispGetAwbMetering
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetAwbMetering(**

                      **viPipe_t viPipe,**

                      :ref:`cnispAwbMetering_t<cnispAwbMetering_t>`  **\* pstAwbMetering,**

**);**

获取白平衡统计信息属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstAwbMetering

  函数入参，指定要获取的白平衡统计信息属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。
