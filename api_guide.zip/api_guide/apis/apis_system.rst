系统控制
########################################

系统控制部分包含了 ISP 公共属性配置、初始化 ISP Firmware、运行 ISP firmware、退
出 ISP firmware和设置 ISP 各模块等功能。

.. _cnispInit:

cnispInit
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispInit(viPipe_t viPipe);**

初始化ISP firmware。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispMemInit:

cnispMemInit
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispMemInit(viPipe_t viPipe);**

初始化ISP外部寄存器。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispRun:

cnispRun
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispRun(viPipe_t viPipe);**

运行ISP firmware。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispExit:

cnispExit
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispExit(viPipe_t viPipe);**

退出ISP firmware。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetControl:

cnispSetControl
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetControl(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispControl_t<cnispControl_t>`  **\* pstControl,**

**);**

设置控制属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstControl

  函数入参，指定要设置的控制属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetControl:

cnispGetControl
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetControl(**

                      **viPipe_t viPipe,**

                      :ref:`cnispControl_t<cnispControl_t>`  **\* pstControl,**

**);**

获取控制属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstControl

  函数入参，指定要获取的控制属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetPub:

cnispSetPub
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetPub(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispPub_t<cnispPub_t>`  **\* pstPub,**

**);**

设置公共属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstPub

  函数入参，指定要设置的公共属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetPub:

cnispGetPub
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetPub(**

                      **viPipe_t viPipe,**

                      :ref:`cnispPub_t<cnispPub_t>`  **\* pstPub,**

**);**

获取公共属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstPub

  函数入参，指定要获取的公共属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetByPass:

cnispSetByPass
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetByPass(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispByPass_t<cnispByPass_t>`  **\* pstByPass,**

**);**

设置ByPass属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstByPass

  函数入参，指定要设置的ByPass属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetByPass:

cnispGetByPass
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetByPass(**

                      **viPipe_t viPipe,**

                      :ref:`cnispByPass_t<cnispByPass_t>`  **\* pstByPass,**

**);**

获取ByPass属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstByPass

  函数入参，指定要获取的ByPass属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetCrossBar:

cnispSetCrossBar
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetCrossBar(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispCrossBar_t<cnispCrossBar_t>`  **\* pstCrossBar,**

**);**

设置Crossbar（图像输入到输出的4到4任意路由）属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCrossBar

  函数入参，指定要设置的CrossBar属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetCrossBar:

cnispGetCrossBar
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetCrossBar(**

                      **viPipe_t viPipe,**

                      :ref:`cnispCrossBar_t<cnispCrossBar_t>`  **\* pstCrossBar,**

**);**

获取CrossBar属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstCrossBar

  函数入参，指定要获取的CrossBar属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetTpg1:

cnispSetTpg1
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetTpg1(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispTpg1_t<cnispTpg1_t>`  **\* pstTpg1,**

**);**

设置第一路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg1

  函数入参，指定要设置的第一路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetTpg1:

cnispGetTpg1
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetTpg1(**

                      **viPipe_t viPipe,**

                      :ref:`cnispTpg1_t<cnispTpg1_t>`  **\* pstTpg1,**

**);**

获取第一路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg1

  函数入参，指定要获取的第一路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetTpg2:

cnispSetTpg2
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetTpg2(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispTpg2_t<cnispTpg2_t>`  **\* pstTpg2,**

**);**

设置第二路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg2

  函数入参，指定要设置的第二路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetTpg2:

cnispGetTpg2
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetTpg2(**

                      **viPipe_t viPipe,**

                      :ref:`cnispTpg2_t<cnispTpg2_t>`  **\* pstTpg2,**

**);**

获取第二路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg2

  函数入参，指定要获取的第二路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetTpg3:

cnispSetTpg3
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetTpg3(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispTpg3_t<cnispTpg3_t>`  **\* pstTpg3,**

**);**

设置第三路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg3

  函数入参，指定要设置的第三路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetTpg3:

cnispGetTpg3
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetTpg3(**

                      **viPipe_t viPipe,**

                      :ref:`cnispTpg3_t<cnispTpg3_t>`  **\* pstTpg3,**

**);**

获取第三路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg3

  函数入参，指定要获取的第三路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetTpg4:

cnispSetTpg4
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetTpg4(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispTpg4_t<cnispTpg4_t>`  **\* pstTpg4,**

**);**

设置第四路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg4

  函数入参，指定要设置的第四路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetTpg4:

cnispGetTpg4
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetTpg4(**

                      **viPipe_t viPipe,**

                      :ref:`cnispTpg4_t<cnispTpg4_t>`  **\* pstTpg4,**

**);**

获取第四路测试图像属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstTpg4

  函数入参，指定要获取的第四路测试图像属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetInputFormat:

cnispSetInputFormat
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetInputFormat(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispInputFormat_t<cnispInputFormat_t>`  **\* pstInputFormat,**

**);**

设置输入格式属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstInputFormat

  函数入参，指定要设置的输入格式属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetInputFormat:

cnispGetInputFormat
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetInputFormat(**

                      **viPipe_t viPipe,**

                      :ref:`cnispInputFormat_t<cnispInputFormat_t>`  **\* pstInputFormat,**

**);**

获取输入格式属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstInputFormat

  函数入参，指定要获取的输入格式属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispSetDecompander:

cnispSetDecompander
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispSetDecompander(**

                      **viPipe_t viPipe,**

                      **const** :ref:`cnispDecompander_t<cnispDecompander_t>`  **\* pstDecompander,**

**);**

设置解压缩属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDecompander

  函数入参，指定要设置的解压缩属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。

.. _cnispGetDecompander:

cnispGetDecompander
++++++++++++++++++++++++++++++++++++++++++++++++++++++

**cnS32_t cnispGetDecompander(**

                      **viPipe_t viPipe,**

                      :ref:`cnispDecompander_t<cnispDecompander_t>`  **\* pstDecompander,**

**);**

获取解压缩属性。

**参数说明**

* viPipe

  函数入参，指定的viPipe号。

* pstDecompander

  函数入参，指定要获取的解压缩属性。

**返回值**

* 0

  函数执行成功。

* 非0

  函数执行失败。详细错误码信息，参考 :ref:`cnispRetCode` 的介绍。

**注意事项**

无。

**环境依赖**

* 头文件：cn_comm_isp.h、cn_isp.h
* 库文件：libisp.so

**使用举例**

无。
