#! /bin/bash

set -e

tags="iksdk"

make clean

#while read line
#  do
#    #echo $line
#    k=${line%=*}
#    v=${line#*=}
#    #remove space in head and tail
#    kv=$(echo $k | awk 'gsub(/^ *| *$/,"")')
#    vv=$(echo $v | awk 'gsub(/^ *| *$/,"")')
#   
#    #echo "kv is $kv"
#    #echo "vv is $vv"
#    if [ "$kv" = "BUILDDIR" ];
#       then
#       #echo "the dir is $vv"; 
#       SphinxBuildDir="$vv";
#       #echo "sphinxbuilddir is $SphinxBuildDir";
#       break
#    fi
#   
# done < ./Makefile

#从Makefile中得到build目录，并去除多余空格
SphinxBuildDir=`grep -m 1 BUILDDIR Makefile | awk -F = '{gsub(/^ *| *$/,"",$NF);print $NF;}'`

sphinx-build -M latexpdf ./source $SphinxBuildDir/latex/ -t $tags

