编程指南
========================================

文件目录
########################################

如下图所示，ISP的文件在CE3226V100 SDK中会分为两个部分，一部分是存放在Image中的刷机文件，另一部分是存放在Package中的二次开发文件。

在按照《寒武纪CE3226V100 SDK使用开发指南》中cnmps-sdk的刷机方式升级之后，会在Target的终端的/mps/lib和/mps/ko目录中看到对应的ISP的库文件和驱动文件。

在按照《寒武纪CE3226V100 SDK使用开发指南》中cnmps-sdk的二次开发部署步骤进行操作后，会在主机端看到对应的ISP的头文件（Include）、库文件（Lib）、驱动文件（Ko）和驱动的中间编译文件（Obj）。

ISP SDK 刷机文件和二次开发文件目录结构如下所示：

.. figure:: ../doc_image/isp_folder.png

        ISP 目录结构

编程模型
########################################

ISP 软件流程
+++++++++++++++++++++++++++++++++++++++

ISP完整的软件运行流程如下：

1. 在启动流水之初，配置VI和MIPI，建立sensor、MIPI和VI之间的基本传输通道。
2. 初始化ISP，并将sensor的回调函数注册到ISP Fimware中，供ISP Firmware后续调节sensor。
3. 初始化ISP的寄存器，建立ISP和VI通道之间的联系。
4. 根据实际场景配置ISP的公共属性，然后运行ISP，启动ISP的处理。
5. 处理完成或者必要时，调用退出函数，结束ISP整个流水。

ISP软件流程图如下：

.. figure:: ../doc_image/isp_pipeline.png

        ISP 软件流程


ISP 示例代码
+++++++++++++++++++++++++++++++++++++++

在开发包部署之后，可以在 ``cnmps-sdk-xxx/board/develop_workspace/mps/sample`` 中看到名为 ``vio`` 的示例代码文件夹和介绍示例代码使用方法的readme文件。

以下内容是抽象简化之后的部分代码示例：

::

    cnS32_t s32Vipipe;
    cnS32_t s32Ret;    
    cnispPub_t stPub;
    sensor_obj *pstSensor;
    cn_sensor_cfg_t stSensCfg;
    cnS32_t sensor_stream_mode = 0x0;

    /* 配置VI和MIPI */
    ......
    
    /* 初始化ISP */
    s32Ret = cnispInit(s32Vipipe);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”isp init failed!\n”);
        return s32Ret;
    }
   
    /* 注册sensor库 */
    s32Ret = cnispRegSensor(s32Vipipe, pstSensor);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”register sensor failed!\n”);
        return s32Ret;
    }

    /* 设置sensor 模式 */
    s32Ret = cnispSetSensorMode(s32Vipipe, sensor_stream_mode, &stSensCfg);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”set sensor mode failed!\n”);
        return s32Ret;
    }

    /* 初始化ISP外部寄存器 */
    s32Ret = cnispMemInit(s32Vipipe);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”isp memory init failed!\n”);
        return s32Ret;
    }

    /* 配置公共属性 */
    s32Ret = cnispSetPub(s32Vipipe, &stPub);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”isp set public attribute failed!\n”);
        return s32Ret;
    }

    /* 运行ISP */
    s32Ret = cnispRun(s32Vipipe);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {  
        printf(”isp run failed!\n”);
        return s32Ret;
    }

    /* 退出ISP */
    s32Ret = cnispExit(s32Vipipe);
    if(CN_ISP_PARA_SUCCESS != s32Ret)
    {
        printf(”isp exit failed!\n”);
        return s32Ret;
    }

    return s32Ret;

