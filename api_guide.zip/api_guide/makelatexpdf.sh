#! /bin/bash

make clean

make latexpdf

