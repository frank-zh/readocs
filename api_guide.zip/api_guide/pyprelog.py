#!/usr/bin/python
# -*- coding: UTF-8

'''
Created on 2020年12月18日
该文件用来解析输出是否有告警，有告警停止编译，并保存到stderr.log文件中。
忽略的告警请加入conf.json中
@author: songmaowang

'''
import os
import sys
import re
import json
import codecs
import shutil
import platform

filepathlist=os.path.split(os.path.realpath(__file__))
currfilepath=filepathlist[0]

def __getignorewarning__():
    jsonfile = currfilepath+'/conf.json'
    #print(jsonfile)
    with codecs.open(jsonfile,"r+",encoding = 'utf-8') as load_f:
       load_dict = json.load(load_f)
       return load_dict["ignorewarndes"],load_dict["ignorewarnkey"]

'''
从makelatexpdf.sh文件中解析出标准输出和错误输出文件，方便解析
'''
def __getstderrfilename():
    
    stdout = ''
    stderr = ''

    shfilepath=currfilepath+'/makelatexpdf_auto.sh'
    #print(shfilepath)
    try:
        if platform.system().lower() == 'linux':
            with open(shfilepath,"r") as f:
                fstr = f.read()
            
            #用正则表达式查找source和build文件夹具体路径
            searchstr = r"stdout *= *(\S+)"
            m = re.search(searchstr, fstr, re.M|re.I|re.U )
            stdout = m.group(1) #匹配到的第一个即为stdout文件名
            
            searchstr = r"stderr *= *(\S+)"
            m = re.search(searchstr, fstr, re.M|re.I|re.U )
            stderr = m.group(1) #匹配到的第一个即为stderr文件名
            
        return stdout,stderr
    except Exception as e:
        print(e)
        return
'''
def __parselatexarg(stdout,stderr,ignorelist,ignorekey):
    #make latex命令产生的告警都会保存在stderr文件中，只要判断该文件中的告警是否在忽略告警里就可以了，不在忽略告警里，则肯定有错误，停止执行
    if not os.path.exists(stderr):
        return True
    print(ignorelist)
    print(ignorekey)
    
    fs = codecs.open(stdout, "r+",encoding = 'utf-8')
    strline = fs.readline()
    
    while strline:
        #一行一行的读取内容，判断是否在忽略告警里面
        print("latexparse: %s " % strline)
        if not (strline in ignorelist): #如果错误不在忽略告警里面
            #如果不能整行匹配，再判断该行是否包含需忽略的告警的关键字
            for igkey in ignorekey:
                if igkey in strline: #如果忽略的关键字包含在改行中，则该行告警直接忽略。
                    break
            return False         
        strline = fs.readline()
    fs.close
    return True
'''
#判断该关键字是否在告警中，在告警中则返回true，不在告警中则返回fasle
def __JudgeWarnKey(keystr,warnstr):
    
    #先判断是否为组合关键字
    if "&&" in keystr:
        #解析组合关键字为字符串列表
        keyls = keystr.split("&&")
        isignore = True  #默认该告警为忽略，如果组合关键字其中一个关键字没匹配上，则该告警不能忽略。
        for i in range(0,len(keyls)):
            if keyls[i].strip().lower() not in warnstr.lower():
                isignore =False
                break
        return isignore
    else:
        if keystr.lower() in warnstr.lower(): 
            return True  #忽略告警在告警字符串里面，则返回true，表示该告警可以忽略
        else:
            return False
    
def __parselatexarg(stdout,stderr,ignorelist,ignorekey):
    '''
    #make latex命令产生的告警都会保存在stderr文件中，只要判断该文件中的告警是否在忽略告警里就可以了，不在忽略告警里，则肯定有错误，停止执行
    '''
    if not os.path.exists(stdout):
        return True
    
    fs = codecs.open(stdout, "r+",encoding = 'utf-8')
    fstr = fs.read()   #先将所有内容读取到字符串中，方便正则表达式查找
    fs.close

    #查找带warning的内容
    pattern = re.compile(r"([\s\S].*)WARNING:([\s\S].*)", re.I | re.U)
    mobjarr = pattern.finditer(fstr)
    
    #打开stderr文件，方便后续写
    fe = codecs.open(stderr, "w+",encoding = 'utf-8')
    isNotError = True
    for mobj in mobjarr:
        amarr = mobj.group()
        
        if amarr == '':
                continue
            
        amarr = amarr.strip()
        amarr = amarr.strip('\r')
        amarr = amarr.strip('\n')
        amarr = amarr.strip()  #再去掉首尾空格，避免多余的空格出现
        
        #print("pdfparse: \n%s" % amarr)
        #判断该告警是否在忽略列表里，不在忽略列表里，要写入stderr文件
        if amarr.lower() not in [elem.lower() for elem in ignorelist]: #如果错误不在忽略告警里面
            #如果不能整行匹配，再判断该行是否包含需忽略的告警的关键字
            isWrite = False  #默认不能忽略
            for igkey in ignorekey:

                isWrite = __JudgeWarnKey(igkey,amarr) 
                if isWrite:
                    break;
                
            if isWrite == False:
                #写入stderr文件
                isNotError = False
                print("make latex Error description: \n%s" % amarr)
                fe.writelines(amarr+'\n')
    fe.close 
       
    return isNotError
    
def __parsepdfarg(stdout,stderr,ignorelist,ignorekey):
    '''
    make all-pdf命令产生的所有输出都只会保存在stdout中，因此从stdout中判断是否有告警内容
    '''
    stdoutfilepath = currfilepath+'/'+stdout
    stderrfilepath = currfilepath+'/'+stderr

    if not os.path.exists(stdoutfilepath):
        return True
    
    fs = codecs.open(stdoutfilepath, "r+",encoding = 'utf-8')
    fstr = fs.read()   #先将所有内容读取到字符串中，方便正则表达式查找
    fs.close
    #查找latexmk的位置，latexmk位置的开始即make all-pdf打印输出的开始
    searchstr = r"latexmk"
    m = re.search(searchstr, fstr, re.I|re.U )
    if m == None:
        return True
    
    spos = m.span()  #获取位置
    latexcont = fstr[spos[0]:len(fstr)]  #获取到make all-pdf产生的内容
    
    #查找带warning的内容
    pattern = re.compile(r'([\s\S].*)Warning([\s\S].*)',  re.I|re.U)
    mobjarr = pattern.finditer(latexcont)
    
    #打开stderr文件，方便后续写
    fe = codecs.open(stderrfilepath, "a+",encoding = 'utf-8')
    isNotError = True
    for mobj in mobjarr:
        amarr = mobj.group()
        #print("pdfparse: %s \n" % amarr)
        if amarr == '':
                continue
        amarr = amarr.strip()
        amarr = amarr.strip('\r')
        amarr = amarr.strip('\n')
        amarr = amarr.strip()  #再去掉首尾空格，避免多余的空格出现
        
        #判断该告警是否在忽略列表里，不在忽略列表里，要写入stderr文件
        if amarr.lower() not in [elem.lower() for elem in ignorelist]: #如果错误不在忽略告警里面
            #如果不能整行匹配，再判断该行是否包含需忽略的告警的关键字
            isWrite = False  #默认不能忽略
            for igkey in ignorekey:

                isWrite = __JudgeWarnKey(igkey,amarr) 
                if isWrite:
                    break;
                
            if isWrite == False:
                #写入stderr文件
                isNotError = False
                print("make all-pdf Error description: \n%s" % amarr)
                fe.writelines(amarr+'\n')
    fe.close 
       
    return isNotError

'''
解析传入参数
第一个参数:latex,即解析make latex命令是否有错误输出。
第二个参数：pdf，即解析make all-pdf命令是否有错误输出。
'''
def main():
    
    if len(sys.argv) < 1:        
        print("WARNING: no args!\n") 
    
    stdout,stderr = __getstderrfilename()
    if stdout=="" or stderr=="":
        print("WARNING: makelatexpdf.sh文件中没有指定标准输出和错误输出文件！\n")
    #print(stdout,stderr)
    arg1 = sys.argv[1]
    #print(arg1)
    
    ignorelist,ignorekey = __getignorewarning__()
    
    if arg1=="latex":
        #print("TIP: Whether there are errors in parsing")
        if not __parselatexarg(stdout,stderr,ignorelist,ignorekey):
            #print("Error:have a latex error_xxxx\n" )
            sys.exit(1)
        else:
            sys.exit(0)
    if arg1=="pdf":
        #print("TIP: Whether there are errors in parsing")
        if not __parsepdfarg(stdout,stderr,ignorelist,ignorekey):
            #print("Error: There is an error!See %s file for detailed error information." % stderr)
            sys.exit(1)
        else:
            sys.exit(0)

if __name__ == '__main__':
    
    main()


